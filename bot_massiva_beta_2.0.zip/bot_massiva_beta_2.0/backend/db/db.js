// backend/db/db.js
require("dotenv").config();
const mysql = require("mysql2");
const fs = require("fs");
const path = require("path");

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
}).promise();

const obterConexao = async () => {
    try {
        const connection = await pool.getConnection();
        return connection;
    } catch (error) {
        console.error("❌ Erro ao obter conexão com o banco:", error);
        throw error;
    }
};

const inicializarBanco = async () => {
    let connection;
    try {
        connection = await obterConexao();
        const scriptPath = path.join(__dirname, "init_db.sql");
        const sqlScript = fs.readFileSync(scriptPath, "utf8");

        // Remove comentários SQL antes de dividir
        const sqlSemComentarios = sqlScript.replace(/--.*\n/g, '');

        // Divide comandos SQL corretamente
        const comandos = sqlSemComentarios
            .split(";") // Divide pelos pontos e vírgulas
            .map(comando => comando.trim()) // Remove espaços extras
            .filter(comando => comando.length > 0); // Remove comandos vazios

        // Executa cada comando individualmente
        for (const comando of comandos) {
            console.log(`🟢 Executando: ${comando.substring(0, 50)}...`);
            await connection.query(comando);
        }

        console.log("✅ Script de inicialização do banco executado com sucesso.");
    } catch (error) {
        console.error("❌ Erro ao executar o script de inicialização do banco:", error);
    } finally {
        if (connection) connection.release();
    }
};


const registrarLog = async (descricao) => {
    let connection;
    try {
        connection = await obterConexao();
        await connection.query("INSERT INTO tb_logs (descricao) VALUES (?)", [descricao]);
    } catch (error) {
        console.error("❌ Erro ao registrar log:", error);
    } finally {
        if (connection) connection.release();
    }
};

const MAX_RETRIES = 3;
const RETRY_DELAY = 5000;

const conectarComRetry = async (tentativa = 1) => {
    try {
        const connection = await obterConexao();
        console.log("✅ Conexão ao banco bem-sucedida!");
        connection.release();
        await inicializarBanco();
    } catch (error) {
        console.error(`❌ Erro ao conectar ao banco (tentativa ${tentativa}/${MAX_RETRIES}):`, error);
        if (tentativa < MAX_RETRIES) {
            console.log(`⏳ Tentando novamente em ${RETRY_DELAY / 1000} segundos...`);
            setTimeout(() => conectarComRetry(tentativa + 1), RETRY_DELAY);
        } else {
            process.exit(1);
        }
    }
};

conectarComRetry();

module.exports = { pool, registrarLog };

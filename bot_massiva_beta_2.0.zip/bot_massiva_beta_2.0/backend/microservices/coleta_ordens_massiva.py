# backend\microservices\microservicoBotMassiva.py:
from dotenv import load_dotenv
from datetime import datetime, timedelta
import asyncio
import mysql.connector
import os
import sys
import json
import logging
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../apis')))
from wfm_basico import consultaWFM_basico
from wfm_full import consultaWFM_full
from odsURA import consultaApiURA
from scraping import scraping_savvion
from mudanca_status import mudar_status_ordem


# Carregar variáveis de ambiente do arquivo .env
load_dotenv()

# Função para conectar ao banco de dados
def conectar_banco():
    try:
        conexao = mysql.connector.connect(
            host=os.getenv("DB_HOST"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD"),
            database=os.getenv("DB_NAME")
        )
        cursor_mysql = conexao.cursor()
        try:
            cursor_mysql.execute("SET lc_time_names = 'pt_BR';")
        finally:
            cursor_mysql.close()
        return conexao
    except mysql.connector.Error as e:
        logging.error(f"Erro ao conectar no MySQL: {str(e)}")
        return None

# Função para capturar ordens entrantes que ainda não foram processadas
def capturar_ordens_entrantes(conexao):
    consulta = """
    SELECT ORDEM, ORDEM_FULL, DATA_ABERTURA, HORA_ABERTURA, STATUS_ORDEM, MOTIVO_ORDEM, PRODUTO, INSTANCIA, 
           DESIGNADOR_BANDA, DESIGNADOR_TV, REDE_ACESSO, TECNOLOGIA, VERIFICACAO
    FROM tb_monit_entrantes
    WHERE VERIFICACAO = %s;
    """
    try:
        cursor = conexao.cursor(dictionary=True)
        cursor.execute(consulta, ("V0",))
        ordens = cursor.fetchall()
        return ordens
    except mysql.connector.Error as e:
        logging.error(f"Erro ao capturar ordens entrantes: {str(e)}")
        return []
    finally:
        cursor.close()

# Função para atualizar o status de uma ordem como processada
def marcar_ordem_como_processada(conexao, ordem):
    try:
        consulta = """
        UPDATE tb_monit_entrantes
        SET VERIFICACAO = %s
        WHERE ORDEM = %s;
        """
        cursor = conexao.cursor()
        cursor.execute(consulta, ("V1", ordem))
        conexao.commit()
    except mysql.connector.Error as e:
        logging.error(f"Erro ao atualizar ordem {ordem}: {e}")
    finally:
        cursor.close()

# Função para capturar o tipo de status e motivo de regra
def capturar_status_motivo_regra(conexao):
    consulta = """
    SELECT STATUS_ORDEM, MOTIVO_ORDEM FROM GTEO.tb_automacao_massiva_status
    """
    try:
        cursor = conexao.cursor(dictionary=True)
        cursor.execute(consulta)
        status_motivo = cursor.fetchall()
        return status_motivo
    except mysql.connector.Error as e:
        logging.error(f"Erro ao capturar status e motivo da regra: {str(e)}")
        return []
    finally:
        cursor.close()

# Função para capturar a janela de regras
def capturar_janela_regra(conexao):
    consulta = """
    SELECT REDE_ACESSO, TECNOLOGIA, MAS_CATEGORIA, MAS_TIPO_PROBLEMA, MAS_JANELA_RECOLHIMENTO 
    FROM GTEO.tb_automacao_massiva_regra
    """
    try:
        cursor = conexao.cursor(dictionary=True)
        cursor.execute(consulta)
        janela_regra = cursor.fetchall()

        # Convertendo 'MAS_JANELA_RECOLHIMENTO' para horas
        for item in janela_regra:
            if isinstance(item['MAS_JANELA_RECOLHIMENTO'], timedelta):
                item['MAS_JANELA_RECOLHIMENTO'] = item['MAS_JANELA_RECOLHIMENTO'].total_seconds() / 3600

        return janela_regra
    except mysql.connector.Error as e:
        logging.error(f"Erro ao capturar a janela de regras: {str(e)}")
        return []
    finally:
        cursor.close()

# Função para capturar status da ordem:
def capturar_situacao(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        situacao = (work_order_item[0].get("wor1:status", "Ainda não mapeado") if isinstance(
                   work_order_item := respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None), list) else
                   work_order_item.get("wor1:status", "Ainda não mapeado") if isinstance(
                   work_order_item, dict) else "Ainda não mapeado")
        return situacao
    except Exception as e:
        logging.error(f"Erro ao capturar situação: {e}")

# Função para capturar motivo da ordem:
def capturar_motivo_ordem(respWFMFull):
    try:
        motivo_ordem = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:statusReason", "Ainda não mapeado")
        return motivo_ordem
    except Exception as e:
        logging.error(f"Erro ao capturar motivo da ordem: {e}")

# Função para validar regra de status e motivo:
def valida_status_motivo(mas_status, mas_motivo, status_regra):
    for regra in status_regra:
        status = regra.get('STATUS_ORDEM')
        motivo = regra.get('MOTIVO_ORDEM')

        # Verifica se o status da ordem está na regra
        if mas_status == status:
            # Verifica se o motivo também está na regra
            if mas_motivo == motivo:
                logging.info(f"Validação OK: Status '{mas_status}' e Motivo '{mas_motivo}' encontrados.")
                return True
            else:
                logging.debug(f"Motivo '{mas_motivo}' não encontrado para Status '{mas_status}'.")
                continue
        else:
            logging.debug(f"Status '{mas_status}' não encontrado na regra atual.")
            continue

    # Se não encontrar o status ou motivo compatível, retorna False
    return False

async def capturar_validar_ODS(instDesignBL, mas_produto):
    # Executa a função assíncrona consultaApiURA e armazena o resultado na variável respODSUra
    respODSUra = await consultaApiURA(instDesignBL)

    # Captura os valores do dicionário retornado
    mas_voz = respODSUra.get('masVoz')
    mas_dados = respODSUra.get('masDados')
    mas_tv = respODSUra.get('masTV')
    mas_categoria = respODSUra.get('masCategoria')
    mas_tipoProblema = respODSUra.get('masTipoProblema')
    mas_dataHoraInicio = respODSUra.get('masDataInicio')
    mas_dataHoraPrevista = respODSUra.get('masDataPrevista')

    # Escolha a fonte de informação correta baseada em mas_produto
    fonte = None
    if mas_produto == 'LINHA':
        fonte = mas_voz or mas_dados or mas_tv
    elif mas_produto == 'BANDA':
        fonte = mas_dados or mas_voz or mas_tv
    elif mas_produto == 'TV':
        fonte = mas_tv or mas_dados or mas_voz

    if fonte is None:
        return  # Se não houver nenhuma fonte válida, simplesmente retorne

    # Determina o status usando a fonte selecionada
    infoScraping = scraping_savvion(fonte)

    # Captura os valores do infoScraping retornado
    mas_numODS = infoScraping.get('nMassiva')
    mas_regiao = infoScraping.get('regiao')
    mas_localidade = infoScraping.get('localidade')
    mas_situacaoMassiva = infoScraping.get('situacaoMassiva')
    mas_dataHoraInicio = infoScraping.get('dataInicio')
    mas_dataHoraEncerramento = infoScraping.get('dataEncerramento')

    # Verifica se a ODS está integrada ao Savvion
    mas_integracao = not all(
        valor == '' for valor in [mas_numODS, mas_regiao, mas_localidade, mas_situacaoMassiva, mas_dataHoraInicio, mas_dataHoraEncerramento]
    )

    print(mas_integracao)
    print(mas_dados)

    # Verifica se a ODS está ativa ou não
    mas_statusODS = None
    if mas_integracao == True:
        if (mas_numODS != '' and mas_localidade != '' and mas_situacaoMassiva != '' and mas_dataHoraInicio != '' and mas_dataHoraEncerramento == ''):
            mas_statusODS = True
        elif (mas_numODS != '' and mas_localidade != '' and mas_situacaoMassiva != '' and mas_dataHoraInicio != '' and mas_dataHoraEncerramento != ''):
            mas_statusODS = False
    # elif (mas_numODS != '' and mas_localidade != '' and mas_situacaoMassiva != '' and mas_dataHoraInicio != '' and mas_dataHoraEncerramento != ''):
    #         mas_statusODS = False

    # Cria o dicionário de informações da ODS
    info_ODS = {
        "mas_voz": mas_voz,
        "mas_dados": mas_dados,
        "mas_tv": mas_tv,
        "mas_categoria": mas_categoria,
        "mas_tipoProblema": mas_tipoProblema,
        "mas_dataHoraInicio": mas_dataHoraInicio,
        "mas_dataHoraPrevista": mas_dataHoraPrevista,
        "mas_dataHoraEncerramento": mas_dataHoraEncerramento,
        "mas_statusODS": mas_statusODS,
        "mas_integracao": mas_integracao,
    }
    return info_ODS

# Função fornecida (com adição de mensagens de debug)
def valida_janela(mas_dataHoraAberturaOrdem, mas_dataHoraInicioODS, mas_redeAcesso, mas_tecnologia, mas_categoria, mas_tipoProblema, janela_regra):
    for regra in janela_regra:
        regra_redeAcesso = regra['REDE_ACESSO']
        regra_tecnologia = regra['TECNOLOGIA']
        regra_categoria = regra['MAS_CATEGORIA']
        regra_tipoProblema = regra['MAS_TIPO_PROBLEMA']

        # Verificação de correspondência das regras
        if mas_redeAcesso == regra_redeAcesso:
            if mas_tecnologia == regra_tecnologia:
                if mas_categoria == regra_categoria:
                    if mas_tipoProblema == regra_tipoProblema:
                        try:
                            regra_janelaRecolhimento = timedelta(hours=regra['MAS_JANELA_RECOLHIMENTO'])
                            dataHoraInicio = datetime.strptime(mas_dataHoraInicioODS, '%d/%m/%Y %H:%M')
                            dataHoraAbertura = datetime.strptime(mas_dataHoraAberturaOrdem, '%Y-%m-%dT%H:%M:%S')

                            inicioMenosJanela = dataHoraInicio - regra_janelaRecolhimento

                            # Validações para determinar o valor de mas_regra
                            if dataHoraAbertura >= inicioMenosJanela and dataHoraAbertura < dataHoraInicio:
                                mas_regra = 'ANTES'
                                mas_difJanela = dataHoraInicio - dataHoraAbertura
                                horas, resto = divmod(mas_difJanela.total_seconds(), 3600)
                                minutos, segundos = divmod(resto, 60)
                                diferenca_formatada = f"{int(horas):02}:{int(minutos):02}:{int(segundos):02}"
                                return mas_regra, diferenca_formatada, regra_janelaRecolhimento

                            elif dataHoraAbertura >= dataHoraInicio:
                                mas_regra = 'DURANTE'
                                mas_difJanela = dataHoraInicio - dataHoraAbertura
                                horas, resto = divmod(mas_difJanela.total_seconds(), 3600)
                                minutos, segundos = divmod(resto, 60)
                                diferenca_formatada = f"{int(horas):02}:{int(minutos):02}:{int(segundos):02}"
                                return mas_regra, diferenca_formatada, regra_janelaRecolhimento

                            elif dataHoraAbertura < inicioMenosJanela:
                                mas_regra = 'FORA DA REGRA'
                                mas_difJanela = dataHoraInicio - dataHoraAbertura
                                horas, resto = divmod(mas_difJanela.total_seconds(), 3600)
                                minutos, segundos = divmod(resto, 60)
                                diferenca_formatada = f"{int(horas):02}:{int(minutos):02}:{int(segundos):02}"
                                return mas_regra, diferenca_formatada, regra_janelaRecolhimento

                            logging.info(f"Validação OK: Rede de Acesso '{mas_redeAcesso}', Tecnologia '{mas_tecnologia}', Categoria '{mas_categoria}', Tipo Problema '{mas_tipoProblema}' e Janela '{regra_janelaRecolhimento}' encontrados.")
                        except Exception as e:
                            logging.error(f"Erro ao calcular a janela de recolhimento: {e}")
                            return None, None
                    else:
                        logging.debug(f"Tipo Problema '{mas_tipoProblema}' não encontrado para na cascata de validação.")
                    continue
                else:
                    logging.debug(f"Categoria '{mas_categoria}' não encontrada para na cascata de validação.")
                continue
            else:
                logging.debug(f"Tecnologia '{mas_tecnologia}' não encontrada para na cascata de validação.")
            continue
        else:
            logging.debug(f"Rede Acesso '{mas_redeAcesso}' não encontrada para na cascata de validação.")
        continue
    return "REGRA NÃO ENCONTRADA", None, None

def cadastra_dados_ods(conexao, mas_voz, mas_dados, mas_tv, mas_categoria, mas_tipoProblema, mas_data_inicio, mas_hora_inicio, mas_data_previsao, mas_hora_previsao, mas_data_encerramento, mas_hora_encerramento, mas_statusODS, mas_integracao):
    try:
        cursor_mysql = conexao.cursor()

        # Verificar se já existe um registro com os mesmos dados chave (defina quais colunas são únicas)
        sql_verificacao = """
            SELECT COUNT(*) 
            FROM GTEO.tb_cad_dados_ODS 
            WHERE MAS_VOZ = %s AND MAS_DADOS = %s AND MAS_TV = %s AND MAS_CATEGORIA = %s
        """
        valores_verificacao = (mas_voz, mas_dados, mas_tv, mas_categoria)
        cursor_mysql.execute(sql_verificacao, valores_verificacao)
        (count,) = cursor_mysql.fetchone()

        if count == 0:  # Se não existe registro, então insere
            sql_insercao = """
                INSERT INTO GTEO.tb_cad_dados_ODS 
                (MAS_VOZ, MAS_DADOS, MAS_TV, MAS_CATEGORIA, MAS_TIPO_PROBLEMA, MAS_DATA_INICIO, MAS_HORA_INICIO, MAS_DATA_PREVISAO, MAS_HORA_PREVISAO, MAS_DATA_ENCERRAMENTO, MAS_HORA_ENCERRAMENTO, MAS_STATUS_ODS, MAS_INTEGRACAO) 
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            valores_insercao = (mas_voz, mas_dados, mas_tv, mas_categoria, mas_tipoProblema, mas_data_inicio, mas_hora_inicio, mas_data_previsao, mas_hora_previsao, mas_data_encerramento, mas_hora_encerramento, mas_statusODS, mas_integracao)
            cursor_mysql.execute(sql_insercao, valores_insercao)
            conexao.commit()

        else:
            logging.info(f"Registro duplicado: {mas_voz}, {mas_dados}, {mas_tv}, {mas_categoria}")

    except mysql.connector.Error as e:
        logging.error(f"Erro ao inserir dados no MySQL: {str(e)}")
    finally:
        cursor_mysql.close()

def validacao_virada(conexao, mas_statusOrdem, mas_motivoOrdem, mas_statusODS, mas_regra, mas_ordem, mas_voz, mas_dados, mas_tv, mas_difTempo):
    try:
        cursor_mysql = conexao.cursor()

        # Verificar se já existe um registro com os mesmos dados chave (defina quais colunas são únicas)
        sql_verificacao = """
            SELECT COUNT(*) 
            FROM GTEO.tb_ordens_aberta_massiva 
            WHERE ORDEM = %s AND MAS_VOZ = %s AND MAS_DADOS = %s AND MAS_TV = %s
        """
        valores_verificacao = (mas_ordem, mas_voz, mas_dados, mas_tv)
        cursor_mysql.execute(sql_verificacao, valores_verificacao)
        (count,) = cursor_mysql.fetchone()

        if count == 0:  # Se não existe registro, então insere
            if (mas_statusOrdem == 'Pendente' and mas_motivoOrdem == 'Aberta Massiva' and mas_statusODS and (mas_regra == 'ANTES' or mas_regra == 'DURANTE')):
                sql = """
                    INSERT INTO GTEO.tb_ordens_aberta_massiva 
                    (ORDEM, MAS_VOZ, MAS_DADOS, MAS_TV, MAS_REGRA, MAS_DIF_JANELA, DATA_ASSOCIACAO, HORA_ASSOCIACAO, BOT_RESPONSAVEL) 
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                valores = (mas_ordem, mas_voz, mas_dados, mas_tv, mas_regra, mas_difTempo, None, None, 'bot_OUTROS')
                cursor_mysql.execute(sql, valores)
                conexao.commit()

            elif (not (mas_statusOrdem == 'Pendente' and mas_motivoOrdem == 'Aberta Massiva') and mas_statusODS and (mas_regra == 'ANTES' or mas_regra == 'DURANTE')):
                sql = """
                    INSERT INTO GTEO.tb_ordens_aberta_massiva 
                    (ORDEM, MAS_VOZ, MAS_DADOS, MAS_TV, MAS_REGRA, MAS_DIF_JANELA, DATA_ASSOCIACAO, HORA_ASSOCIACAO, BOT_RESPONSAVEL) 
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                data_associacao = datetime.now().strftime("%Y-%m-%d")
                hora_associacao = datetime.now().strftime("%H:%M:%S")
                valores = (mas_ordem, mas_voz, mas_dados, mas_tv, mas_regra, mas_difTempo, data_associacao, hora_associacao, 'bot_GTEO')
                cursor_mysql.execute(sql, valores)
                conexao.commit()

            elif (mas_statusODS and (mas_regra == 'FORA DA REGRA' or mas_regra == 'REGRA NÃO ENCONTRADA')):
                sql = """
                    INSERT INTO GTEO.tb_ordens_aberta_massiva_FR 
                    (ORDEM, MAS_VOZ, MAS_DADOS, MAS_TV, MAS_REGRA, MAS_DIF_JANELA, DATA_ASSOCIACAO, HORA_ASSOCIACAO, BOT_RESPONSAVEL) 
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                valores = (mas_ordem, mas_voz, mas_dados, mas_tv, mas_regra, mas_difTempo, None, None, 'bot_GTEO')
                cursor_mysql.execute(sql, valores)
                conexao.commit()

        else:
            logging.info(f"Registro duplicado: {mas_ordem}, {mas_voz}, {mas_dados}, {mas_tv}")

    except mysql.connector.Error as e:
        logging.error(f"Erro ao inserir dados no MySQL: {str(e)}")
    finally:
        cursor_mysql.close()
# ----------------------------------------------------------------------------------------------------------------------------------------------
# Fluxo principal para processar as ordens
async def processar_ordens():
    conexao = conectar_banco()
    if conexao is None:
        print("Falha ao conectar ao banco de dados")
        return

    try:
        # Capturar as ordens entrantes
        ordens = capturar_ordens_entrantes(conexao)
        if not ordens:
            print("Nenhuma ordem entrante encontrada.")
            return
        # Capturar as regras
        status_motivo_regra = capturar_status_motivo_regra(conexao)
        janela_regra = capturar_janela_regra(conexao)

        # Processar cada ordem
        for ordem in ordens:
            mas_ordem = ordem['ORDEM']
            mas_ordemFull = ordem['ORDEM_FULL']
            mas_dataAbertura = ordem['DATA_ABERTURA']
            mas_horaAbertura = ordem['HORA_ABERTURA']
            mas_dataHoraAbertura = f"{mas_dataAbertura.replace('/', '-')}T{mas_horaAbertura}"
            mas_statusOrdem = ordem['STATUS_ORDEM']
            mas_motivoOrdem = ordem['MOTIVO_ORDEM']
            mas_produto = ordem['PRODUTO'].upper()
            mas_instancia = ordem['INSTANCIA']
            mas_designadorBanda = ordem['DESIGNADOR_BANDA']
            mas_designadorTV = ordem['DESIGNADOR_TV']
            mas_redeAcesso = ordem['REDE_ACESSO']
            mas_tecnologia = ordem['TECNOLOGIA']
            mas_voz = None
            mas_dados = None
            mas_tv = None
            mas_categoria = None
            mas_tipoProblema = None
            mas_dataHoraInicio = None
            mas_dataHoraPrevista = None
            mas_dataHoraEncerramento = None
            mas_integracao = None
            mas_statusODS = None

            print(f"Processando ordem: {mas_ordem}")

            try:
                # Consulta o valor de mas_ordemFull na API WFM Basico
                respWFMBasico = await consultaWFM_basico(mas_ordem)
                if respWFMBasico is None:
                    logging.error(f"API WFM Basico retornou None pra ordem {mas_ordem}")
                    continue

                # Consulta o valor de mas_ordemFull na API WFM Basico
                respWFMFull = await consultaWFM_full(mas_ordemFull)
                if respWFMFull is None:
                    logging.error(f"API WFM Basico retornou None pra ordem {mas_ordemFull}")
                    continue

                mas_statusOrdem = capturar_situacao(respWFMBasico)
                mas_motivoOrdem = capturar_motivo_ordem(respWFMFull)

                validacaoStatus = valida_status_motivo(mas_statusOrdem, mas_motivoOrdem, status_motivo_regra)

                if validacaoStatus == True:
                    instDesignBL = mas_instancia if mas_produto == 'LINHA' else mas_designadorBanda

                    info_ODS = await capturar_validar_ODS(instDesignBL, mas_produto)

                    if info_ODS != None:
                        mas_voz = info_ODS.get('mas_voz')
                        mas_dados = info_ODS.get('mas_dados')
                        mas_tv = info_ODS.get('mas_tv')
                        mas_categoria = info_ODS.get('mas_categoria')
                        mas_tipoProblema = info_ODS.get('mas_tipoProblema')
                        mas_dataHoraInicio = info_ODS.get('mas_dataHoraInicio')

                        # Convertendo a string em um objeto datetime
                        data_hora_inicio_obj = datetime.strptime(mas_dataHoraInicio, "%d/%m/%Y %H:%M")

                        # Extraindo a data e a hora
                        mas_data_inicio = data_hora_inicio_obj.strftime("%d/%m/%Y")
                        mas_hora_inicio = data_hora_inicio_obj.strftime("%H:%M")
                        mas_dataHoraPrevista = info_ODS.get('mas_dataHoraPrevista')

                        # Convertendo a string em um objeto datetime
                        data_hora_prevista_obj = datetime.strptime(mas_dataHoraPrevista, "%Y-%m-%dT%H:%M:%S.%f")

                        # Extraindo a data e a hora
                        mas_data_previsao = data_hora_prevista_obj.strftime("%Y-%m-%d")
                        mas_hora_previsao = data_hora_prevista_obj.strftime("%H:%M:%S")

                        mas_dataHoraEncerramento = info_ODS.get('mas_dataHoraEncerramento')
                        mas_statusODS = info_ODS.get('mas_statusODS')
                        mas_integracao = info_ODS.get('mas_integracao')
                        mas_data_encerramento = None
                        mas_hora_encerramento = None

                        validacaoJanela = valida_janela(mas_dataHoraAbertura, mas_dataHoraInicio, mas_redeAcesso, mas_tecnologia, mas_categoria, mas_tipoProblema, janela_regra)

                        if validacaoJanela != None:
                            mas_regra, mas_difTempo, regra_janelaRecolhimento = validacaoJanela

                        # Verifica se regra_janelaRecolhimento não é None antes de tentar convertê-lo
                        if regra_janelaRecolhimento is not None:
                            janela_recolhimento_horas = regra_janelaRecolhimento.total_seconds() / 3600
                        else:
                            janela_recolhimento_horas = None

                        cadastra_dados_ods(conexao, mas_voz, mas_dados, mas_tv, mas_categoria, mas_tipoProblema, mas_data_inicio, mas_hora_inicio, mas_data_previsao, mas_hora_previsao, mas_data_encerramento, mas_hora_encerramento, mas_statusODS, mas_integracao)
                        validacao_virada(conexao, mas_statusOrdem, mas_motivoOrdem, mas_statusODS, mas_regra, mas_ordem, mas_voz, mas_dados, mas_tv, mas_difTempo)
                        
                        # Chamar API para mudar status se a ordem foi validada como "Aberta Massiva"
                        if mas_statusODS and (mas_regra == 'ANTES' or mas_regra == 'DURANTE'):
                            print(f"🔄 Mudando status da ordem {mas_ordemFull} para 'Aberta Massiva'...")

                            # Chamar a API para mudar o status
                            resultado_api = await mudar_status_ordem(mas_voz or mas_dados or mas_tv, mas_ordemFull)

                            if resultado_api == "Sucesso":
                                print(f"✅ Status da ordem {mas_ordemFull} alterado com sucesso!")

                                # Capturar data e hora do momento da mudança
                                data_associacao = datetime.now().strftime("%Y-%m-%d")
                                hora_associacao = datetime.now().strftime("%H:%M:%S")

                                # Inserir a ordem na tabela GTEO.tb_ordens_aberta_massiva
                                try:
                                    cursor_mysql = conexao.cursor()

                                    sql_insercao = """
                                        INSERT INTO GTEO.tb_ordens_aberta_massiva 
                                        (ORDEM, MAS_VOZ, MAS_DADOS, MAS_TV, MAS_REGRA, MAS_DIF_JANELA, 
                                        DATA_ASSOCIACAO, HORA_ASSOCIACAO, BOT_RESPONSAVEL) 
                                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                                    """
                                    valores = (
                                        mas_ordem, mas_voz, mas_dados, mas_tv, mas_regra, mas_difTempo,
                                        data_associacao, hora_associacao, 'bot_GTEO'
                                    )
                                    cursor_mysql.execute(sql_insercao, valores)
                                    conexao.commit()

                                    print(f"✅ Ordem {mas_ordem} registrada na tabela tb_ordens_aberta_massiva.")

                                except mysql.connector.Error as e:
                                    logging.error(f"Erro ao inserir ordem {mas_ordem} na tabela tb_ordens_aberta_massiva: {str(e)}")

                                finally:
                                    cursor_mysql.close()

                                # Marcar a ordem como processada no banco
                                marcar_ordem_como_processada(conexao, mas_ordem)

                            else:
                                print(f"⚠️ Falha ao mudar status da ordem {mas_ordemFull}. Ordem NÃO será marcada como processada para tentar novamente mais tarde.")

                        dadosOrdemMassiva = {
                            "mas_ordem": mas_ordem,
                            "mas_redeAcesso": mas_redeAcesso,
                            "mas_tecnologia": mas_tecnologia,
                            "mas_dataHoraAbertura": mas_dataHoraAbertura,
                            "mas_voz": mas_voz,
                            "mas_dados": mas_dados,
                            "mas_tv": mas_tv,
                            "mas_categoria": mas_categoria,
                            "mas_tipoProblema": mas_tipoProblema,
                            "mas_dataHoraInicio": mas_dataHoraInicio,
                            "mas_dataHoraPrevista": mas_dataHoraPrevista,
                            "mas_janela": janela_recolhimento_horas,  
                            "mas_statusODS": mas_statusODS,
                            "mas_integracao": mas_integracao,
                            "mas_regra": mas_regra,
                            "mas_difTempo": mas_difTempo
                        }                        

                        # Carregar o conteúdo existente do arquivo JSON se existir
                        if os.path.exists('listaConferenciaMassiva.json'):
                            with open('listaConferenciaMassiva.json', 'r', encoding='utf-8') as json_file:
                                try:
                                    listaConferenciaMassiva = json.load(json_file)
                                except json.JSONDecodeError:
                                    listaConferenciaMassiva = []
                        else:
                            listaConferenciaMassiva = []

                        # Adiciona a nova ordem à lista
                        listaConferenciaMassiva.append(dadosOrdemMassiva)

                        # Gravar a lista atualizada no arquivo JSON
                        with open('listaConferenciaMassiva.json', 'w', encoding='utf-8') as json_file:
                            json.dump(listaConferenciaMassiva, json_file, ensure_ascii=False, indent=4)

                else:
                    # print(f"validacaoStatus", validacaoStatus)
                    continue
                    
            except Exception as api_error:
                logging.error(f"Erro ao processar API para a ordem {mas_ordem}: {str(api_error)}")
                continue
            
            # Aqui irá a lógica para validar status/motivo e associar massiva, etc.
            marcar_ordem_como_processada(conexao, mas_ordem)
            # print(f"Ordem {mas_ordem} marcada como processada.")

    finally:
        conexao.close()

# Função principal para 
async def main():
    resultado = await processar_ordens()
    print(resultado)

# Função para rodar o processo de 
async def run_forever():
    while True:
        await main()
        print("Aguardando 1 minuto para a próxima extração...")
        await asyncio.sleep(300)  # Pausa de 1 minuto (60 segundos)

# Iniciar o processo 
if __name__ == '__main__':
    try:
        asyncio.run(run_forever())
    except KeyboardInterrupt:
        print("Processo interrompido pelo usuário.")
# backend/microservices/limpeza_dados.py
from sqlalchemy import create_engine, text
import os
from datetime import datetime, timedelta
from dotenv import load_dotenv
import logging

# Carregar variáveis de ambiente
dotenv_path = os.path.join(os.path.dirname(__file__), "../.env")
load_dotenv(dotenv_path)

# Configuração do banco de dados
DATABASE_URL = f"mysql+mysqlconnector://{os.getenv('DB_USER')}:{os.getenv('DB_PASSWORD')}@{os.getenv('DB_HOST')}/{os.getenv('DB_NAME')}"
engine = create_engine(DATABASE_URL)

# Configuração de logging
os.makedirs('logs', exist_ok=True)
logging.basicConfig(
    filename='logs/limpeza_dados.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Definir tamanho do lote para exclusão de registros em massa
BATCH_SIZE = 1000

def limpar_dados():
    """
    Remove dados antigos do banco de dados em lotes para evitar bloqueios excessivos.
    """
    data_limite = (datetime.now() - timedelta(days=90)).strftime("%Y-%m-%d")
    tabelas = ["GTEO.tb_monit_entrantes", "GTEO.tb_coleta_ordens"]
    
    with engine.connect() as connection:
        for tabela in tabelas:
            while True:
                try:
                    # Excluir registros antigos em lotes
                    result = connection.execute(text(
                        f"DELETE FROM {tabela} WHERE DATA_ABERTURA < :data_limite LIMIT :batch_size"
                    ), {"data_limite": data_limite, "batch_size": BATCH_SIZE})
                    
                    registros_deletados = result.rowcount
                    
                    if registros_deletados == 0:
                        break  # Se não há mais registros a deletar, interrompe o loop.
                    
                    logging.info(f"🗑️ {registros_deletados} registros removidos da tabela {tabela}.")
                
                except Exception as e:
                    logging.error(f"❌ Erro ao limpar a tabela {tabela}: {e}")
                    break
    
    logging.info("🗑️ Limpeza concluída com sucesso.")
    print("🗑️ Limpeza concluída.")

if __name__ == "__main__":
    limpar_dados()

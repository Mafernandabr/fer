# backend\microservices\coleta_ordens.py:
import logging
import os
import sys
import time
import urllib.parse
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine, text
from datetime import datetime
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

sys.stdout.reconfigure(encoding='utf-8')

# Criar pasta de logs, caso não exista
os.makedirs("logs", exist_ok=True)

# Configuração de logging
logging.basicConfig(
    filename="logs/coleta_ordens.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

# Conectar ao banco de dados BD_23
try:
    password = urllib.parse.quote(os.getenv("DB23_PASSWORD"))  # Escapar caracteres especiais
    DATABASE_URL = (
        f"mssql+pyodbc://{os.getenv('DB23_USERNAME')}:{password}@{os.getenv('DB23_SERVER')},"
        f"{os.getenv('DB23_PORT')}/{os.getenv('DB23_DATABASE')}?driver=ODBC+Driver+17+for+SQL+Server&TrustServerCertificate=yes"
    )
    engine = create_engine(DATABASE_URL, pool_size=10, max_overflow=5, connect_args={"timeout": 10})
    SessionLocal = sessionmaker(bind=engine)
    logging.info("✅ Conexão com o banco de dados BD_23 estabelecida.")
except Exception as e:
    logging.error(f"❌ Erro ao conectar ao banco de dados BD_23: {e}")
    raise

# Conectar ao banco de dados ESPELHO BC_BD_23
try:
    password = urllib.parse.quote(os.getenv("DB_PASSWORD"))  # Escapa caracteres especiais
    DATABASE_URL = f"mysql+mysqlconnector://{os.getenv('DB_USER')}:{password}@{os.getenv('DB_HOST')}/{os.getenv('DB_NAME')}"
    engine = create_engine(DATABASE_URL, pool_size=10, max_overflow=5, connect_args={"connect_timeout": 10})
    SessionLocal = sessionmaker(bind=engine)
    logging.info("✅ Conexão com o banco de dados Espelho BC_BD_23 estabelecida.")
except Exception as e:
    logging.error(f"❌ Erro ao conectar ao banco de dados Espelho BC_BD_23: {e}")
    raise

# Conectar ao banco de dados TTMonitor_banco
try:
    password = urllib.parse.quote(os.getenv("TT_DB_PASSWORD"))  # Escapa caracteres especiais
    TT_DATABASE_URL = f"mysql+mysqlconnector://{os.getenv('TT_DB_USER')}:{password}@{os.getenv('TT_DB_HOST')}/{os.getenv('TT_DB_NAME')}"
    tt_engine = create_engine(TT_DATABASE_URL, pool_size=10, max_overflow=5, connect_args={"connect_timeout": 10})
    TTSessionLocal = sessionmaker(bind=tt_engine)
    logging.info("✅ Conexão com o banco de dados TTMonitor_banco estabelecida.")
except Exception as e:
    logging.error(f"❌ Erro ao conectar ao banco de dados TTMonitor_banco: {e}")
    raise

# Configuração de retries
MAX_RETRIES = 3
RETRY_DELAY = 5  # Segundos

# Variável para controlar a execução contínua
coletando_ordens = True

def tentar_executar_query(session, query, params=None, descricao=""):
    """Executa uma query SQL com retries automáticos em caso de erro."""
    for tentativa in range(1, MAX_RETRIES + 1):
        try:
            if params:
                result = session.execute(text(query), params)
            else:
                result = session.execute(text(query))

            session.commit()
            return result.fetchall() if "SELECT" in query.upper() else None

        except Exception as e:
            logging.error(f"❌ Erro na tentativa {tentativa}/{MAX_RETRIES} - {descricao}: {e}")
            print(f"❌ Erro na tentativa {tentativa}/{MAX_RETRIES} - {descricao}: {e}")

            if tentativa < MAX_RETRIES:
                print(f"⏳ Tentando novamente em {RETRY_DELAY} segundos...")
                time.sleep(RETRY_DELAY)
            else:
                logging.error(f"🚨 Falha definitiva ao executar {descricao}. Pulando para a próxima etapa.")
                return None

def coletar_ordens():
    global coletando_ordens
    print("🔍 Iniciando a coleta de ordens...")

    while coletando_ordens:
        try:
            session = SessionLocal()
            tt_session = TTSessionLocal()
            hoje = datetime.now().strftime("%Y-%m-%d")

            # 🔹 Coleta de BC_BD_23 - Verifica IDs onde TIME_CRG é hoje
            print("✅ Conectado ao banco BC_BD_23, executando query...")
            novas_ordens = tentar_executar_query(
                session,
                "SELECT ID FROM BC_BD_23 WHERE DATE(TIME_CRG) = :hoje",
                {"hoje": hoje},
                "Consulta BC_BD_23"
            )

            if novas_ordens:
                for ordem in novas_ordens:
                    id_ordem = ordem[0]

                    # Verifica se já existe na tabela tb_coleta_ordens
                    existe = tentar_executar_query(
                        session,
                        "SELECT 1 FROM tb_coleta_ordens WHERE ORDEM = :ordem",
                        {"ordem": id_ordem},
                        f"Verificação ordem {id_ordem} em BC_BD_23"
                    )
                    
                    if not existe:
                        tentar_executar_query(
                            session,
                            """
                            INSERT INTO tb_coleta_ordens (ORDEM, DATA_SINCRONISMO, HORA_SINCRONISMO, BD_ORIGEM, LOG_ENRIQUECIMENTO)
                            VALUES (:ordem, CURDATE(), CURTIME(), 'E_BD_23', 'NOK')
                            """,
                            {"ordem": id_ordem},
                            f"Inserção ordem {id_ordem} em tb_coleta_ordens"
                        )
                        print(f"✅ Ordem {id_ordem} coletada do BC_BD_23.")

            # 🔹 Coleta de TTMonitor_banco - Verifica TICKET_CODE onde DATA_ABERTURA é hoje
            print("✅ Conectado ao banco TTMonitor_banco, executando query...")
            novas_ordens_tt = tentar_executar_query(
                tt_session,
                "SELECT TICKET_CODE FROM TTMonitor_banco WHERE DATE(DATA_ABERTURA) = :hoje",
                {"hoje": hoje},
                "Consulta TTMonitor_banco"
            )

            if novas_ordens_tt:
                for ordem_tt in novas_ordens_tt:
                    ticket_code = ordem_tt[0]

                    # Verifica se já existe na tabela tb_coleta_ordens
                    existe_tt = tentar_executar_query(
                        session,
                        "SELECT 1 FROM tb_coleta_ordens WHERE ORDEM = :ordem",
                        {"ordem": ticket_code},
                        f"Verificação ordem {ticket_code} em TTMonitor_banco"
                    )

                    if not existe_tt:
                        tentar_executar_query(
                            session,
                            """
                            INSERT INTO tb_coleta_ordens (ORDEM, DATA_SINCRONISMO, HORA_SINCRONISMO, BD_ORIGEM, LOG_ENRIQUECIMENTO)
                            VALUES (:ordem, CURDATE(), CURTIME(), 'TT_Monitor', 'NOK')
                            """,
                            {"ordem": ticket_code},
                            f"Inserção ordem {ticket_code} em tb_coleta_ordens"
                        )
                        print(f"✅ Ordem {ticket_code} coletada do TTMonitor_banco.")

            session.close()
            tt_session.close()

        except Exception as e:
            print(f"❌ Erro geral na coleta de ordens: {e}")
            logging.error(f"❌ Erro geral na coleta de ordens: {e}")

        time.sleep(10)  # Espera 10 segundos antes de rodar novamente

if __name__ == "__main__":
    coletar_ordens()
# backend\microservices\enriquecimento_ordens.py
from dotenv import load_dotenv
from datetime import datetime
import json
import sys
import os
import asyncio
import aiomysql
import traceback

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../apis')))
from interpretador import fluxo_execucao

# Carregar variáveis de ambiente do arquivo .env
load_dotenv()

# Número de requisições simultâneas permitidas
NUMERO_DE_SEMAFOROS = 10

# Criar pool de conexões MySQL
async def get_mysql_pool():
    return await aiomysql.create_pool(
        host=os.getenv("DB_HOST"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        db=os.getenv("DB_NAME"),
        minsize=1,
        maxsize=10,
        autocommit=True
    )

# Função para verificar se a ordem já existe no banco de dados
async def verificar_ordem_existente(ordem_val, pool):
    if pool.closed:
        raise RuntimeError("Pool de conexões está fechado.")
    
    async with pool.acquire() as conn:
        async with conn.cursor() as cursor:
            await cursor.execute("SELECT COUNT(*) FROM GTEO.tb_monit_entrantes WHERE ORDEM = %s", (ordem_val,))
            resultado = await cursor.fetchone()
            return resultado[0] > 0  # Se o resultado for maior que 0, a ordem já existe

# Função assíncrona para processar uma ordem com semáforo e timeout
async def processar_ordem_com_semaforo(ordem, semaphore, pool):
    async with semaphore:
        ordem_val = ordem[0]  
        bd_origem = ordem[1]  

        try:
            if await verificar_ordem_existente(ordem_val, pool):
                print(f"⚠️ Ordem {ordem_val} já existe no banco. Pulando...")
                return

            print(f"📌 Processando ordem {ordem_val} | Origem: {bd_origem}")

            try:
                resultado = await asyncio.wait_for(fluxo_execucao(ordem_val), timeout=60)  # Aumentei o timeout para 60 segundos
            except asyncio.TimeoutError:
                print(f"⏳ Timeout ao processar a ordem {ordem_val}. Pulando para a próxima.")
                return

            print("📊 Conteúdo de resultado:")
            print(json.dumps(resultado, indent=4, ensure_ascii=False))

            # Extração de dados com tratamento para valores nulos ou "Ainda não mapeado"
            dados_ordem = resultado.get('dados_ordem', {})
            dados_cliente = resultado.get('dados_cliente', {})
            detalhe_ordem = resultado.get('detalhe_ordem', {})
            posicao_fisica = resultado.get('posicao_fisica', {})
            produtos_contratados = resultado.get('produtos_contratados', {})

            # Dados da Ordem
            ordem_val      = dados_ordem.get('ordem', 'Não informado')
            sistema_origem = dados_ordem.get('sistema_origem', 'Não informado')
            protocolo      = dados_ordem.get('protocolo', 'Não informado')
            data_abertura  = dados_ordem.get('data_abertura', 'Não informado')
            hora_abertura  = dados_ordem.get('hora_abertura', 'Não informado')

            # Dados do Cliente
            segmento = dados_cliente.get('segmento', 'Não informado')
            rank     = dados_cliente.get('rank', 'Não informado')

            # Detalhes da Ordem
            ordem_full          = detalhe_ordem.get('ordem_full', 'Não informado')
            sequencia           = detalhe_ordem.get('sequencia', 'Não informado')
            posicao_X           = detalhe_ordem.get('posicao_X', 0)
            posicao_Y           = detalhe_ordem.get('posicao_Y', 0)
            codigo_rua          = detalhe_ordem.get('codigo_rua', 'Não informado')
            micro_area          = detalhe_ordem.get('micro_area', 'Não informado')
            acronimo            = detalhe_ordem.get('acronimo', 'Não informado')
            liberado            = detalhe_ordem.get('liberado', 'Não informado')
            rede_externa        = detalhe_ordem.get('rede_externa', 'Não informado')
            rede_acesso         = detalhe_ordem.get('rede_acesso', 'Não informado')
            tecnologia          = detalhe_ordem.get('tecnologia', 'Não informado')
            tipo_ordem          = detalhe_ordem.get('tipo_ordem', 'Não informado')
            produto             = detalhe_ordem.get('produto', 'Não informado')
            detalhe             = detalhe_ordem.get('detalhe', 'Não informado')
            status_ordem        = detalhe_ordem.get('situacao', 'Não informado')
            motivo_ordem        = detalhe_ordem.get('motivo_ordem', 'Não informado')
            motivo_cancelamento = detalhe_ordem.get('motivo_cancelamento', 'Não informado')
            cidade              = detalhe_ordem.get('cidade', 'Não informado')
            uf                  = detalhe_ordem.get('estado', 'Não informado')
            cluster             = detalhe_ordem.get('cluster', 'Não informado')
            regional            = detalhe_ordem.get('regional', 'Não informado')
            repetido_7dias      = detalhe_ordem.get('repetido_7dias', 'Não informado')
            repetido_15dias     = detalhe_ordem.get('repetido_15dias', 'Não informado')
            repetido_30dias     = detalhe_ordem.get('repetido_30dias', 'Não informado')
            ordem_raiz          = detalhe_ordem.get('ordem_raiz', None)
            dif_dias            = detalhe_ordem.get('quant_dias', None)

            # Posição Física
            id_fibra            = posicao_fisica.get('id_fibra', 'Não informado')
            id_ont              = posicao_fisica.get('id_ont', 'Não informado')
            cnl                 = posicao_fisica.get('cnl', 'Não informado')
            es                  = posicao_fisica.get('es', 'Não informado')
            at                  = posicao_fisica.get('at', 'Não informado')
            cto_tipo_end        = posicao_fisica.get('cto_tipo_end', 'Não informado')
            cto_nome_end        = posicao_fisica.get('cto_nome_end', 'Não informado')
            cto_num_end         = posicao_fisica.get('cto_num_end', 'Não informado')
            cto_id_caixa        = posicao_fisica.get('cto_id_caixa', 'Não informado')
            armario_olt         = posicao_fisica.get('armario_olt', 'Não informado')
            shelf               = posicao_fisica.get('shelf', 'Não informado')
            vlan_rede_rin       = posicao_fisica.get('vlan_rede_rin', 'Não informado')
            vlan_usuario        = posicao_fisica.get('vlan_usuario', 'Não informado')
            vlan_multicast      = posicao_fisica.get('vlan_multicast', 'Não informado')
            vlan_audiencia      = posicao_fisica.get('vlan_audiencia', 'Não informado')
            vlan_unicast        = posicao_fisica.get('vlan_unicast', 'Não informado')
            olt_fabricante      = posicao_fisica.get('olt_fabricante', 'Não informado')
            olt_slot            = posicao_fisica.get('olt_slot', 'Não informado')
            olt_porta           = posicao_fisica.get('olt_porta', 'Não informado')
            cabo                = posicao_fisica.get('cabo', 'Não informado')
            splitter_1          = posicao_fisica.get('splitter_1', 'Não informado')
            splitter_1_end      = posicao_fisica.get('splitter_1_end', 'Não informado')
            splitter_2          = posicao_fisica.get('splitter_2', 'Não informado')
            splitter_2_end      = posicao_fisica.get('splitter_2_end', 'Não informado')
            fibraPorta          = posicao_fisica.get('fibra_porta', 'Não informado')
            bras                = posicao_fisica.get('bras', 'Não informado')

            # Produtos Contratados
            instancia               = produtos_contratados.get('linha_telefônica', {}).get('instancia', 'Não informado')
            design_bl               = produtos_contratados.get('banda_larga', {}).get('designador', 'Não informado')
            design_tv               = produtos_contratados.get('tv_por_assinatura', {}).get('designador', 'Não informado')
            design_ac               = produtos_contratados.get('acesso', {}).get('designador', 'Não informado')
            velocidade_bl           = produtos_contratados.get('banda_larga', {}).get('provisioning', 'Não informado')

            # Data e Hora da Atualização
            bd_origem               = str(bd_origem)
            data_ultima_atualizacao = datetime.now().strftime("%Y-%m-%d")
            hora_ultima_atualizacao = datetime.now().strftime("%H:%M:%S")

            print("\n🔎 **Valores Extraídos:**")
            print(f"  - sistema_origem: {sistema_origem}")
            print(f"  - protocolo: {protocolo}")
            print(f"  - data_abertura: {data_abertura}")
            print(f"  - hora_abertura: {hora_abertura}")
            print(f"  - segmento: {segmento}")
            print(f"  - rank: {rank}")
            print(f"  - ordem_full: {ordem_full}")
            print(f"  - sequencia: {sequencia}")
            print(f"  - posicao_X: {posicao_X}")
            print(f"  - posicao_Y: {posicao_Y}")
            print(f"  - codigo_rua: {codigo_rua}")
            print(f"  - micro_area: {micro_area}")
            print(f"  - acronimo: {acronimo}")
            print(f"  - liberado: {liberado}")
            print(f"  - rede_externa: {rede_externa}")
            print(f"  - rede_acesso: {rede_acesso}")
            print(f"  - tecnologia: {tecnologia}")
            print(f"  - tipo_ordem: {tipo_ordem}")
            print(f"  - produto: {produto}")
            print(f"  - detalhe: {detalhe}")
            print(f"  - status_ordem: {status_ordem}")
            print(f"  - motivo_ordem: {motivo_ordem}")
            print(f"  - motivo_cancelamento: {motivo_cancelamento}")
            print(f"  - cidade: {cidade}")
            print(f"  - estado (UF): {uf}")
            print(f"  - cluster: {cluster}")
            print(f"  - regional: {regional}")
            print(f"  - repetido_7dias: {repetido_7dias}")
            print(f"  - repetido_15dias: {repetido_15dias}")
            print(f"  - repetido_30dias: {repetido_30dias}")
            print(f"  - ordem_raiz: {ordem_raiz}")
            print(f"  - dif_dias: {dif_dias}")
                        
            print(f"  - id_fibra: {id_fibra}")
            print(f"  - id_ont: {id_ont}")
            print(f"  - cnl: {cnl}")
            print(f"  - es: {es}")
            print(f"  - at: {at}")
            print(f"  - cto_tipo_end: {cto_tipo_end}")
            print(f"  - cto_nome_end: {cto_nome_end}")
            print(f"  - cto_num_end: {cto_num_end}")
            print(f"  - cto_id_caixa: {cto_id_caixa}")
            print(f"  - armario_olt: {armario_olt}")
            print(f"  - shelf: {shelf}")
            print(f"  - vlan_rede_rin: {vlan_rede_rin}")
            print(f"  - vlan_usuario: {vlan_usuario}")
            print(f"  - vlan_multicast: {vlan_multicast}")
            print(f"  - vlan_audiencia: {vlan_audiencia}")
            print(f"  - vlan_unicast: {vlan_unicast}")
            print(f"  - olt_fabricante: {olt_fabricante}")
            print(f"  - olt_slot: {olt_slot}")
            print(f"  - olt_porta: {olt_porta}")
            print(f"  - cabo: {cabo}")
            print(f"  - splitter_1: {splitter_1}")
            print(f"  - splitter_1_end: {splitter_1_end}")
            print(f"  - splitter_2: {splitter_2}")
            print(f"  - splitter_2_end: {splitter_2_end}")
            print(f"  - fibraPorta: {fibraPorta}")
            print(f"  - bras: {bras}")
            
            print(f"  - instancia: {instancia}")
            print(f"  - design_banda_larga: {design_bl}")
            print(f"  - design_tv: {design_tv}")
            print(f"  - design_ac: {design_ac}")
            print(f"  - velocidade_banda_larga: {velocidade_bl}")
            print(f"  - bd_origem: {bd_origem}")
            print(f"  - data_ultima_atualizacao: {data_ultima_atualizacao}")
            print(f"  - hora_ultima_atualizacao: {hora_ultima_atualizacao}")

            async with pool.acquire() as conn:
                async with conn.cursor() as cursor:
                    await cursor.execute(
                        """
                        INSERT INTO GTEO.tb_monit_entrantes 
                        (ORDEM, SISTEMA_ORIGEM, PROTOCOLO, DATA_ABERTURA, HORA_ABERTURA, SEGMENTO, RANK, ORDEM_FULL, POSICAO_X,
                        POSICAO_Y, REDE_ACESSO, TECNOLOGIA, TIPO_ORDEM, PRODUTO, DETALHE, STATUS_ORDEM, MOTIVO_ORDEM,
                        MOTIVO_CANCELAMENTO, CIDADE, UF, CLUSTER, REGIONAL, REPETIDO_7DIAS, REPETIDO_15DIAS, REPETIDO_30DIAS,
                        ORDEM_RAIZ, DIF_DIAS, ID_FIBRA, ID_ONT, CNL, ES, AT, CTO_TIPO_END, CTO_NOME_END, CTO_NUM_END,
                        CTO_ID_CAIXA, ARMARIO_OLT, SHELF, VLAN_REDE_RIN, VLAN_USUARIO, VLAN_MULTICAST, VLAN_AUDIENCIA,
                        VLAN_UNICAST, OLT_FABRICANTE, OLT_SLOT, OLT_PORTA, CABO, SPLITTER_1, SPLITTER_1_ENDERECO, SPLITTER_2,
                        SPLITTER_2_ENDERECO, FIBRA_PORTA, BRAS, INSTANCIA, DESIGNADOR_BANDA, DESIGNADOR_TV, DESIGNADOR_ACESSO,
                        VELOCIDADE_BL, BD_ORIGEM, DATA_ULTIMA_ATUALIZACAO, HORA_ULTIMA_ATUALIZACAO, VERIFICACAO, LOG_ENRIQUECIMENTO)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
                                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
                                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        """,
                        (ordem_val, sistema_origem, protocolo, data_abertura, hora_abertura, segmento, rank, ordem_full, posicao_X,
                        posicao_Y, rede_acesso, tecnologia, tipo_ordem, produto, detalhe, status_ordem, motivo_ordem,
                        motivo_cancelamento, cidade, uf, cluster, regional, repetido_7dias, repetido_15dias, repetido_30dias,
                        ordem_raiz, dif_dias, id_fibra, id_ont, cnl, es, at, cto_tipo_end, cto_nome_end, cto_num_end, cto_id_caixa,
                        armario_olt, shelf, vlan_rede_rin, vlan_usuario, vlan_multicast, vlan_audiencia, vlan_unicast, olt_fabricante,
                        olt_slot, olt_porta, cabo, splitter_1, splitter_1_end, splitter_2, splitter_2_end, fibraPorta, bras, instancia,
                        design_bl, design_tv, design_ac, velocidade_bl, bd_origem, data_ultima_atualizacao, hora_ultima_atualizacao,
                        'V0', 'OK')
                    )

                    print(f"✅ Dados inseridos com sucesso para a ordem {ordem_val}")

                    await cursor.execute(
                        "UPDATE GTEO.tb_coleta_ordens SET LOG_ENRIQUECIMENTO = 'OK' WHERE ORDEM = %s",
                        (ordem_val,)
                    )
                    print(f"✅ LOG_ENRIQUECIMENTO atualizado para a ordem {ordem_val}")

        except Exception as err:
            erro_detalhado = traceback.format_exc()
            print(f"❌ Erro ao processar a ordem {ordem_val}: {erro_detalhado}")

# Função assíncrona para extrair ordens e enriquecê-las
async def extrair_tb_coleta_ordens(pool):
    async with pool.acquire() as conn:
        async with conn.cursor() as cursor:
            await cursor.execute("""
                SELECT ORDEM, BD_ORIGEM
                FROM GTEO.tb_coleta_ordens
                WHERE LOG_ENRIQUECIMENTO != 'OK'
            """)
            ordens = await cursor.fetchall()

            if not ordens:
                return {"message": "🟢 Nenhuma ordem pendente encontrada na tabela 'tb_coleta_ordens'"}

            semaphore = asyncio.Semaphore(NUMERO_DE_SEMAFOROS)
            tarefas = [processar_ordem_com_semaforo(ordem, semaphore, pool) for ordem in ordens]

            await asyncio.gather(*tarefas)

    return {"message": "🟢 Processo de enriquecimento concluído."}

# Função principal para rodar a extração e enriquecimento
async def main():
    pool = await get_mysql_pool()
    try:
        resultado = await extrair_tb_coleta_ordens(pool)
        print(resultado)
    finally:
        pool.close()
        await pool.wait_closed()

# Função para rodar o processo de enriquecimento em loop com pausa de 1 minuto
async def run_forever():
    pool = await get_mysql_pool()
    try:
        while True:
            await main()
            print("🕒 Aguardando 1 minuto para a próxima extração...")
            await asyncio.sleep(60)
    finally:
        pool.close()
        await pool.wait_closed()

# Iniciar o processo de enriquecimento de ordens
if __name__ == '__main__':
    try:
        asyncio.run(run_forever())
    except KeyboardInterrupt:
        print("🛑 Processo interrompido pelo usuário.")
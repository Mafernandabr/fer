# backend\api\wfm_full.py:
import aiohttp
import xmltodict
import logging
import asyncio

# Configuração de logging
logging.basicConfig(level=logging.INFO)

# Função para consultar a API WFM full com retry e timeout
async def consultaWFM_full(ordem_full, retry_count=3, timeout=10):
    
    url = 'http://esb.gvt.net.br:8888/ResourceManagement/WorkforceManagement/WorkforceManagementReporting/WorkOrderReporting'
    autorization_token = ''

    # Payload SOAP idêntico ao Node.js
    payload = f'''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:wor="http://www.gvt.com.br/ResourceManagement/WorkforceManagement/WorkforceManagementReporting/WorkOrderReporting" xmlns:wor1="http://www.gvt.com.br/ResourceManagement/WorkforceManagement/WorkforceManagementReporting/workOrderReportingEntities" xmlns:get="http://www.gvt.com.br/ResourceManagement/WorkforceManagement/WorkforceManagementReporting/workOrderReportingEntities/GetFullWorkOrderItemEntities">
                        <soapenv:Header/>
                        <soapenv:Body>
                            <wor:getFullWorkOrderItemIn>
                            <wor1:workOrderItem>
                                <get:ID>{ordem_full}</get:ID>
                            </wor1:workOrderItem>
                            </wor:getFullWorkOrderItemIn>
                        </soapenv:Body>
                    </soapenv:Envelope>'''
    headers = {'Content-Type': 'text/xml;charset=UTF-8'}

    for attempt in range(retry_count):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, data=payload, headers=headers, timeout=timeout) as response:
                    response_text = await response.text()

                    # Verifica o status da resposta
                    if response.status != 200:
                        logging.error(f"Erro na API WFM FULL. Status code: {response.status}. Tentativa {attempt + 1} de {retry_count}")
                        continue  # Tenta novamente

                    # Converte o XML para um dicionário usando xmltodict
                    parsed_data = xmltodict.parse(response_text)

                    # Retorna a resposta processada
                    return parsed_data

        except aiohttp.ClientError as client_error:
            logging.error(f"Erro de conexão na API WFM FULL para ordem {ordem_full}. Erro: {client_error}. Tentativa {attempt + 1} de {retry_count}")
        
        except asyncio.TimeoutError:
            logging.error(f"Timeout ao consultar a API WFM FULL para ordem {ordem_full}. Tentativa {attempt + 1} de {retry_count}")
        
        except Exception as e:
            logging.error(f"Erro inesperado ao consultar a API WFM FULL para ordem {ordem_full}. Erro: {e}. Tentativa {attempt + 1} de {retry_count}")

        # Aguardar 2 segundos entre tentativas, exceto na última
        if attempt < retry_count - 1:
            await asyncio.sleep(2)

    # Se todas as tentativas falharem, retorna uma estrutura de dicionário vazia
    logging.error(f"Todas as tentativas falharam para a ordem: {ordem_full}")
    return {
        'soapenv:Envelope': {
            'soapenv:Body': {
                'wor:getFullWorkOrderItemOut': {
                    'wor1:workOrderItem': {
                        'get:workOrder': {
                            'get:WorkOrderComprisedOf': {
                                'get:status': None,
                                'get:statusReason': None
                            }
                        }
                    }
                }
            }
        }
    }
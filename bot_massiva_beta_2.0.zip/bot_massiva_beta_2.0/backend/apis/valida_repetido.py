# backend\api\valida_repetido.py:
import io
import asyncio
import math
import logging
from datetime import datetime
from wfm_full import consultaWFM_full

def captura_lista_ordens(xml_wfmbasico):
    # Acessa a estrutura do XML
    work_order_items = (xml_wfmbasico.get('soapenv:Envelope', {})
                        .get('soapenv:Body', {})
                        .get('wor:findWorkOrderItemOut', {})
                        .get('wor1:workOrderItem', []))
    
    # Verifica se há workOrderItems e captura as ordens
    if not work_order_items:
        print("Nenhum item encontrado")
        return []

    # Cria um objeto com a estrutura pedida, extraindo o valor de 'ordem' de 'ordem_full'
    ordens_capturadas = [{
        "ordem_full": ordem.get('wor1:ID', ''),
        "ordem": ordem.get('wor1:ID', '').split(":")[0] if ":" in ordem.get('wor1:ID', '') else ordem.get('wor1:ID', ''),
        "data_criacao": None,
        "tipo_ordem": None,
        "detalhe": None
    } for ordem in work_order_items if 'wor1:ID' in ordem]
    
    # Exibe as ordens capturadas para verificação
    # print(ordens_capturadas)
    return ordens_capturadas

# Função assíncrona para enriquecer as informações com base no XML completo
async def enriquecimento_lista(ordens_capturadas):
    for item_lista in ordens_capturadas:
        try:
            # Chama a função para consultar o WFM completo
            resp_wfmfull = await consultaWFM_full(item_lista["ordem_full"])

            if resp_wfmfull:
                # Navegar pela estrutura do retorno SOAP para acessar os valores corretos
                work_order_item = resp_wfmfull.get('soapenv:Envelope', {}).get('soapenv:Body', {}).get('wor:getFullWorkOrderItemOut', {}).get('wor1:workOrderItem', {})
                work_order = work_order_item.get('get:workOrder', {})
                work_order_comprised_of = work_order.get('get:WorkOrderComprisedOf', {})

                # Extrair as informações relevantes
                item_lista["data_criacao"] = work_order.get('get:dateOfSale', 'Data não encontrada')
                item_lista["tipo_ordem"] = next((desc['get:value'] for desc in work_order_comprised_of.get('get:WorkOrderItemInvolvesWorkSpec', {}).get('get:specificationDescription', []) if desc['get:label'] == 'TIPO'), 'Tipo não encontrado')
                item_lista["detalhe"] = work_order_comprised_of.get('get:detail', 'Detalhe não encontrado')

            else:
                # Se a resposta estiver vazia ou inválida, mantém os valores como não encontrados
                item_lista["ordem"] = 'ID não encontrado'
                item_lista["data_criacao"] = 'Data não encontrada'
                item_lista["tipo_ordem"] = 'Tipo não encontrado'
                item_lista["detalhe"] = 'Detalhe não encontrado'

        except Exception as e:
            # Captura erros inesperados e pode registrar ou tratar conforme necessário
            logging.error(f"Erro ao enriquecer ordem {item_lista['ordem_full']}: {e}")
            # Adicionar um log detalhado ou enviar para um sistema de logs
            log_error(f"Erro ao enriquecer ordem {item_lista['ordem_full']}: {e}")
            # Mantém os valores como não encontrados em caso de erro
            item_lista["ordem"] = 'Erro na consulta'
            item_lista["data_criacao"] = 'Erro na consulta'
            item_lista["tipo_ordem"] = 'Erro na consulta'
            item_lista["detalhe"] = 'Erro na consulta'

    return ordens_capturadas

# Função para capturar as ordens com a data de criação mais recente e imediatamente anterior
def capturar_ordens_recentes(ordens_enriquecidas):
    # Converter 'data_criacao' de string para objeto datetime para facilitar a comparação
    for ordem in ordens_enriquecidas:
        if ordem["data_criacao"]:
            # print(ordem["data_criacao"])
            # Tenta converter a data para o formato datetime
            try:
                # ordem["data_criacao_dt"] = datetime.strptime(ordem["data_criacao"], "%Y-%m-%dT%H:%M:%S-%f:%S")
                ordem["data_criacao_dt"] = datetime.strptime(ordem["data_criacao"], "%Y-%m-%dT%H:%M:%S%z")
            except ValueError:
                ordem["data_criacao_dt"] = None  # Caso falhe, marque como None
    
    # Filtrar as ordens que possuem uma data válida
    ordens_validas = [ordem for ordem in ordens_enriquecidas if ordem["data_criacao_dt"]]
    
    # Ordenar as ordens por 'data_criacao_dt' em ordem decrescente (mais recente primeiro)
    ordens_ordenadas = sorted(ordens_validas, key=lambda x: x["data_criacao_dt"], reverse=True)
    
    # Verificar se temos pelo menos duas ordens
    if len(ordens_ordenadas) >= 2:
        ordem_mais_recente = ordens_ordenadas[0]
        ordem_anterior = ordens_ordenadas[1]
        return ordem_mais_recente, ordem_anterior
    elif len(ordens_ordenadas) == 1:
        # Se houver apenas uma ordem válida, retorna ela e None como a anterior
        return ordens_ordenadas[0], None
    else:
        # Se nenhuma ordem tiver uma data válida, retorna None para ambas
        return None, None

# Função para aplicar a regra de repetição comparando com a ordem anterior
def aplicar_regra_repeticao(ordens_ordenadas):
    repetido_7dias = "não"
    repetido_15dias = "não"
    repetido_30dias = "não"
    numero_ordem_repetida = None
    diff_dias = None

    # A ordem mais recente é o primeiro item da lista ordenada
    ordem_mais_recente = ordens_ordenadas[0]
    ordem_anterior = ordens_ordenadas[1] if len(ordens_ordenadas) > 1 else None

    numero_ordem_mais_recente = ordem_mais_recente.get("ordem", "")
    data_criacao_mais_recente_str = ordem_mais_recente.get("data_criacao", "")
    tipo_ordem_mais_recente = ordem_mais_recente.get("tipo_ordem", "").upper() if ordem_mais_recente.get("tipo_ordem") else "Ainda não mapeado"
    # print(tipo_ordem_mais_recente)
    detalhe_mais_recente = ordem_mais_recente.get("detalhe", "").upper() if ordem_mais_recente.get("detalhe") else "Ainda não mapeado"

    # Se a ordem mais recente não for do tipo defeito, não é repetida
    if tipo_ordem_mais_recente != "DEFEITO":
        return {
            "repetido_7dias": "não",
            "repetido_15dias": "não",
            "repetido_30dias": "não",
            "numero_ordem_repetida": None,
            "diferenca_dias": None
        }
    
    # Verifica se o detalhe da ordem mais recente começa com "PREV"
    if detalhe_mais_recente.startswith("PREV"):
        return {
            "repetido_7dias": "não",
            "repetido_15dias": "não",
            "repetido_30dias": "não",
            "numero_ordem_repetida": None,
            "diferenca_dias": None
        }

    if ordem_anterior:
        numero_ordem_anterior = ordem_anterior.get("ordem", "")
        data_criacao_anterior_str = ordem_anterior.get("data_criacao", "")
        tipo_ordem_anterior = ordem_anterior.get("tipo_ordem", "").upper() if ordem_anterior.get("tipo_ordem") else "Ainda não mapeado"
        detalhe_anterior = ordem_anterior.get("detalhe", "").upper() if ordem_anterior.get("detalhe") else "Ainda não mapeado"

        # Se a ordem anterior não for do tipo defeito, não é repetida
        if tipo_ordem_anterior != "DEFEITO":
            return {
                "repetido_7dias": "não",
                "repetido_15dias": "não",
                "repetido_30dias": "não",
                "numero_ordem_repetida": None,
                "diferenca_dias": None
            }
        
        # Verifica se o detalhe da ordem anterior começa com "PREV"
        if detalhe_anterior.startswith("PREV"):
            return {
                "repetido_7dias": "não",
                "repetido_15dias": "não",
                "repetido_30dias": "não",
                "numero_ordem_repetida": None,
                "diferenca_dias": None
            }

        try:
            data_criacao_mais_recente = datetime.strptime(data_criacao_mais_recente_str, "%Y-%m-%dT%H:%M:%S%z")
            data_criacao_anterior = datetime.strptime(data_criacao_anterior_str, "%Y-%m-%dT%H:%M:%S%z")

            # Calcula a diferença em dias, arredondando para cima
            diff_dias = math.ceil((data_criacao_mais_recente - data_criacao_anterior).total_seconds() / (60 * 60 * 24))

            # Se a diferença for zero, ou se os detalhes e tipo de ordem forem iguais, a ordem não é considerada repetida
            if diff_dias == 0 and numero_ordem_mais_recente == numero_ordem_anterior and tipo_ordem_mais_recente == tipo_ordem_anterior and detalhe_mais_recente == detalhe_anterior:
                return {
                    "repetido_7dias": "não",
                    "repetido_15dias": "não",
                    "repetido_30dias": "não",
                    "numero_ordem_repetida": None,
                    "diferenca_dias": diff_dias
                }

            # Verifica se a ordem está dentro de um dos intervalos de repetição
            if diff_dias <= 7:
                repetido_7dias = "sim"
                repetido_15dias = "não"
                repetido_30dias = "não"
                numero_ordem_repetida = numero_ordem_anterior
            elif 7 < diff_dias <= 15:
                repetido_7dias = "não"
                repetido_15dias = "sim"
                repetido_30dias = "sim"
                numero_ordem_repetida = numero_ordem_anterior
            elif 15 < diff_dias <= 30:
                repetido_7dias = "não"
                repetido_15dias = "não"
                repetido_30dias = "sim"
                numero_ordem_repetida = numero_ordem_anterior

        except ValueError as e:
            logging.error(f"Erro ao converter datas: {data_criacao_mais_recente_str} ou {data_criacao_anterior_str} - {e}")

    return {
        "repetido_7dias": repetido_7dias,
        "repetido_15dias": repetido_15dias,
        "repetido_30dias": repetido_30dias,
        "numero_ordem_repetida": numero_ordem_repetida,
        "diferenca_dias": diff_dias
    }
   
# Função principal para validar e enriquecer as ordens
async def validar_repetido(xml_wfmbasico):
    # Captura as ordens a partir do XML básico
    ordens_capturadas = captura_lista_ordens(xml_wfmbasico)
    
    # Enriquecer a lista de ordens com base no XML completo
    ordens_enriquecidas = await enriquecimento_lista(ordens_capturadas)

    # Capturar as ordens mais recentes e anteriores
    ordem_mais_recente, ordem_anterior = capturar_ordens_recentes(ordens_enriquecidas)
    
    # Aplicar a regra de repetição
    if ordem_mais_recente and ordem_anterior:
        resultado_repeticao = aplicar_regra_repeticao([ordem_mais_recente, ordem_anterior])
    else:
        resultado_repeticao = {
            "repetido_7dias": "não",
            "repetido_15dias": "não",
            "repetido_30dias": "não",
            "numero_ordem_repetida": None,
            "diferenca_dias": None
        }

    # return {
    #     "ordem_mais_recente": ordem_mais_recente,
    #     "ordem_anterior": ordem_anterior,
    #     "repeticao": resultado_repeticao
    # }
    return resultado_repeticao


import aiohttp
import xmltodict
import asyncio
import logging

# URL da API Massiva
API_URL = "http://esb.gvt.net.br:8888/ResourceManagement/FaultManagement/FaultReportingAndAnalytics/NetworkProblemManagement"

async def mudar_status_ordem(mas, ordem_full):
    """
    Função assíncrona para mudar o status da ordem para 'Aberta Massiva'.
    Faz uma requisição SOAP e retorna 'Sucesso' ou 'Falha'.
    """
    # Corpo da requisição SOAP (XML)
    payload = f"""<?xml version="1.0" encoding="UTF-8"?>
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                      xmlns:gvt="http://www.gvt.com.br/GvtCommonEntities" 
                      xmlns:net="http://www.gvt.com.br/ResourceManagement/FaultManagement/FaultReportingAndAnalytics/NetworkProblemManagement/">
        <soapenv:Header/>
        <soapenv:Body>
            <net:associateWorkOrderItemToNetworkProblemIn>
                <workOrderItem>
                    <networkProblemID>{mas}</networkProblemID>
                    <workOrderItemID>{ordem_full}</workOrderItemID>
                </workOrderItem>
            </net:associateWorkOrderItemToNetworkProblemIn>
        </soapenv:Body>
    </soapenv:Envelope>"""

    headers = {
        "Content-Type": "text/xml;charset=UTF-8"
    }

    try:
        # Faz a requisição assíncrona usando aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.post(API_URL, data=payload, headers=headers) as response:
                response_text = await response.text()

                # Verifica o status HTTP da resposta
                if response.status != 200:
                    logging.error(f"Erro na resposta da API. Status HTTP: {response.status}")
                    return "Falha"

                # Converte a resposta XML para um dicionário
                response_dict = xmltodict.parse(response_text)

                # Verifica se a resposta contém o elemento esperado
                if "soapenv:Envelope" in response_dict:
                    body = response_dict["soapenv:Envelope"].get("soapenv:Body", {})
                    if "net:associateWorkOrderItemToNetworkProblemOut" in body:
                        return "Sucesso"

                return "Falha"

    except Exception as e:
        logging.error(f"Erro ao mudar status da ordem {ordem_full}: {e}")
        return "Falha"

# # Teste da função (remova ou adapte conforme necessário)
# if __name__ == "__main__":
#     asyncio.run(mudar_status_ordem("MAS_12345", "ORD_67890"))

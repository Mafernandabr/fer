import aiohttp
import xmltodict
import asyncio

# Função para localizar o Designador de Acesso
async def localiza_design_acesso(designBL):
    try:
        # URL para enviar solicitação
        url = 'http://esbgvtna2.gvt.net.br:8888/eai/oss/ossturbonet'
        
        # Payload da solicitação
        payload = f'''
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:oss="http://www.gvt.com/ws/eai/oss/ossturbonet">
            <soapenv:Header/>
            <soapenv:Body>
                <oss:getAccessDesignator>
                    <oss:designator>{designBL}</oss:designator>
                </oss:getAccessDesignator>
            </soapenv:Body>
        </soapenv:Envelope>'''

        # Cabeçalhos da solicitação
        headers = {'Content-Type': 'application/xml'}

        # Faz a solicitação POST para o URL especificado com o payload e cabeçalhos
        async with aiohttp.ClientSession() as session:
            async with session.post(url, data=payload, headers=headers) as response:
                # Verifica se a resposta foi bem-sucedida
                if response.status == 200:
                    # Obtém o conteúdo da resposta como texto
                    response_text = await response.text()
                    
                    # Analisa o XML para um dicionário Python, lidando com os namespaces
                    parsed_xml = xmltodict.parse(response_text)
                    # print(parsed_xml)
                    
                    # Captura o valor do design_ac levando em consideração o namespace
                    design_ac = parsed_xml.get('env:Envelope', {}).get('env:Body', {}).get('m:getAccessDesignatorResponse', {}).get('m:return', 'NULL')
                    if design_ac == {'@xsi:nil': 'true'}:
                        design_ac = None

                    # print(f"design_ac", design_ac)

                    return design_ac
                else:
                    print(f"Erro: {response.status}")
                    return 'NULL'

    except Exception as e:
        print(f"Erro: {str(e)}")
        return 'NULL'
    
# Para rodar o fluxo de execução
# designBL = "SCQ-81KIAHMMY-013"  # Substitua pelo valor da ordemBD
# asyncio.run(localiza_design_acesso(designBL))
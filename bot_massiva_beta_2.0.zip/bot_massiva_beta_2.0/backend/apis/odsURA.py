# backend\api\odsURA.py:
import aiohttp
import xmltodict
import asyncio
import logging

# Configuração de logging
logging.basicConfig(level=logging.INFO)

# Função assíncrona para consultar a API URA Massiva e interpretar o XML
async def consultaApiURA(instDesignBL, retry_count=3, timeout=10):
    url = 'http://esb.gvt.net.br:8888/ResourceManagement/FaultManagement/FaultReportingAndAnalytics/NetworkProblemManagementV2_findNetworkAllProblem'
    authorization_token = '3763c74be39d52ba96e4989504f77943ecf72950'

    # Payload SOAP
    payload = f"""<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                    xmlns:net="http://www.gvt.com.br/ResourceManagement/FaultManagement/FaultReportingAndAnalytics/NetworkProblemManagementV2-findNetworkAllProblem/"
                    xmlns:fin="http://www.gvt.com.br/ResourceManagement/FaultManagement/FaultReportingAndAnalytics/NetworkProblemManagementV2-findNetworkAllProblem/findNetworkAllProblemEntities">
                        <soapenv:Header/>
                        <soapenv:Body>
                            <net:findNetworkAllProblemIn>
                                <fin:SystemIdentification>
                                    <fin:id>0</fin:id> 
                                    <fin:authorizationToken>{authorization_token}</fin:authorizationToken>
                                </fin:SystemIdentification>
                                <fin:CustomerFacingService>
                                    <fin:asset>{instDesignBL}</fin:asset>
                                </fin:CustomerFacingService>
                                <fin:Problem>
                                    <fin:status>Ativo</fin:status>
                                </fin:Problem>
                            </net:findNetworkAllProblemIn>
                        </soapenv:Body>
                    </soapenv:Envelope>"""

    headers = {'Content-Type': 'text/xml;charset=UTF-8'}

    # Tentar a requisição com retries
    for attempt in range(retry_count):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, data=payload, headers=headers, timeout=timeout) as response:
                    if response.status == 200:
                        xml = await response.text()
                        return interpretar_xml(xml)
                    else:
                        logging.error(f"Erro na requisição: {response.status}")
        except Exception as e:
            logging.error(f"Erro na tentativa {attempt + 1}: {e}")
        await asyncio.sleep(2)  # Aguarda 2 segundos antes de tentar novamente

    raise Exception("Número máximo de tentativas excedido")

# Função para interpretar o XML usando xmltodict
def interpretar_xml(xml):
    try:
        # Parse do XML
        data = xmltodict.parse(xml)
        body = data.get('soapenv:Envelope', {}).get('soap-env:Body', {})
        if not body or 'net:findNetworkAllProblemOut' not in body:
            return {
                'masDados': None,
                'masVoz': None,
                'masTv': None,
                'masCategoria': None,
                'masTipoProblema': None,
                'masDataInicio': None,
                'masDataPrevista': None,
            }

        network_problems = body['net:findNetworkAllProblemOut'].get('fin:NetworkProblems', None)
        if not network_problems:
            return {
                'masDados': None,
                'masVoz': None,
                'masTv': None,
                'masCategoria': None,
                'masTipoProblema': None,
                'masDataInicio': None,
                'masDataPrevista': None,
            }

        # Garantir que network_problems seja uma lista
        if isinstance(network_problems, dict):
            network_problems = [network_problems]

        masDados = None
        masVoz = None
        masTv = None
        masCategoria = None
        masTipoProblema = None
        masDataInicio = None
        masDataPrevista = None

        # Processar cada problema de rede
        for problem in network_problems:
            problem_details = problem.get('fin:NetworkProblem', {})
            if isinstance(problem_details, dict):
                problem_details = [problem_details]

            for details in problem_details:
                if details.get('fin:resourcesAffected') == 'VOZ':
                    masVoz = problem.get('fin:Problem', {}).get('fin:problemId', None)
                    masCategoria = problem.get('fin:Problem', {}).get('fin:categoryLevel1', None)
                    masTipoProblema = details.get('fin:ProblemHasAssociatedTroubleTicket', {}).get('fin:description', None)
                    masDataInicio = details.get('fin:openDate', None)
                    masDataPrevista = details.get('fin:previsionDate', None)
                elif details.get('fin:resourcesAffected') == 'DADOS':
                    masDados = problem.get('fin:Problem', {}).get('fin:problemId', None)
                    masCategoria = problem.get('fin:Problem', {}).get('fin:categoryLevel1', None)
                    masTipoProblema = details.get('fin:ProblemHasAssociatedTroubleTicket', {}).get('fin:description', None)
                    masDataInicio = details.get('fin:openDate', None)
                    masDataPrevista = details.get('fin:previsionDate', None)
                elif details.get('fin:resourcesAffected') == 'TV':
                    masTv = problem.get('fin:Problem', {}).get('fin:problemId', None)
                    masCategoria = problem.get('fin:Problem', {}).get('fin:categoryLevel1', None)
                    masTipoProblema = details.get('fin:ProblemHasAssociatedTroubleTicket', {}).get('fin:description', None)
                    masDataInicio = details.get('fin:openDate', None)
                    masDataPrevista = details.get('fin:previsionDate', None)

        return {
            'masDados': masDados,
            'masVoz': masVoz,
            'masTv': masTv,
            'masCategoria': masCategoria.upper() if masCategoria else None,
            'masTipoProblema': masTipoProblema.upper() if masTipoProblema else None,
            'masDataInicio': masDataInicio,
            'masDataPrevista': masDataPrevista,
        }

    except Exception as e:
        logging.error(f"Erro ao parsear XML: {e}")
        raise

# Bloco para executar a função de teste
# if __name__ == "__main__":
#     instDesignBL = "SPO-V0001U5J5P-013"
    
#     async def main():
#         resultado = await consultaApiURA(instDesignBL)
#         print(resultado)

#     asyncio.run(main())
# backend\api\scraping.py:
import requests
from bs4 import BeautifulSoup
import time
from requests.adapters import HTTPAdapter
from urllib3.poolmanager import PoolManager
import ssl
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class SSLAdapter(HTTPAdapter):
    def init_poolmanager(self, connections, maxsize, block=False, **pool_kwargs):
        pool_kwargs['ssl_context'] = ssl._create_unverified_context()
        super(SSLAdapter, self).init_poolmanager(connections, maxsize, block=block, **pool_kwargs)

def scraping_savvion(mas, max_retries=3):
    url_tratativa_massiva = f"https://appwfm.gvt.net.br/wfm/networkProblemAdmin/index.jsp?piidMassive=5160001&massiveId={mas}"

    retries = 0
    while retries < max_retries:
        try:
            # Faz a chamada à página web especificada usando requests e realiza scraping com BeautifulSoup
            session = requests.Session()
            session.mount('https://', SSLAdapter())
            response = session.get(url_tratativa_massiva, verify=False, timeout=10)

            # Atraso de 3 segundos para garantir o carregamento completo da página
            time.sleep(3)

            # Verifica se a resposta foi bem-sucedida
            if response.status_code != 200:
                raise requests.exceptions.RequestException(f"Status code {response.status_code}")

            soup = BeautifulSoup(response.text, 'html.parser')

            # Extrai informações relevantes da página web
            n_massiva = soup.select_one("#formPrincipal\\:gridLabels tbody tr:nth-child(1) td:nth-child(2)").get_text(strip=True)
            regiao = soup.select_one("#formPrincipal\\:gridLabels tbody tr:nth-child(2) td:nth-child(2)").get_text(strip=True)
            localidade = soup.select_one("#formPrincipal\\:gridLabels tbody tr:nth-child(3) td:nth-child(2)").get_text(strip=True)
            situacao_massiva = soup.select_one("#formPrincipal\\:gridLabels tbody tr:nth-child(4) td:nth-child(2)").get_text(strip=True)
            data_inicio = soup.select_one("#formPrincipal\\:gridLabels tbody tr:nth-child(5) td:nth-child(2)").get_text(strip=True)
            data_encerramento = soup.select_one("#formPrincipal\\:gridLabels tbody tr:nth-child(6) td:nth-child(2)").get_text(strip=True)

            dados_extraidos = {
                "nMassiva": n_massiva,
                "regiao": regiao,
                "localidade": localidade,
                "situacaoMassiva": situacao_massiva,
                "dataInicio": data_inicio,
                "dataEncerramento": data_encerramento
            }

            return dados_extraidos

        except Exception as error:
            retries += 1
            print(f'Erro ao realizar scraping (tentativa {retries} de {max_retries}):', error)
            time.sleep(2)  # Atraso de 2 segundos antes de tentar novamente

    # Caso todas as tentativas falhem, levanta uma exceção
    raise Exception('Todas as tentativas de scraping falharam.')


# # Exemplo de uso
# resultado = scraping_savvion("25354830")
# print(resultado)
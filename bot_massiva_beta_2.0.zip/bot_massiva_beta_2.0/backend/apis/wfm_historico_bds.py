# backend\api\wfm_historico_bds.py:
import aiohttp
import asyncio
import xmltodict

# Função assíncrona que faz a consulta à API com lógica de retry
async def consultaWFM_historico_BDs(instDesignDef, max_retries=3, retry_delay=10):
    url = 'http://esb.gvt.net.br:8888/ResourceManagement/WorkforceManagement/WorkforceManagementReporting/WorkOrderReporting'
    
    # Construindo o payload SOAP
    payload = f'''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                    xmlns:wor="http://www.gvt.com.br/ResourceManagement/WorkforceManagement/WorkforceManagementReporting/WorkOrderReporting" 
                    xmlns:wor1="http://www.gvt.com.br/ResourceManagement/WorkforceManagement/WorkforceManagementReporting/workOrderReportingEntities">
                    <soapenv:Header/>
                    <soapenv:Body>
                        <wor:findWorkOrderItemIn>
                            <wor1:serviceId>{instDesignDef}</wor1:serviceId>
                        </wor:findWorkOrderItemIn>
                    </soapenv:Body>
                  </soapenv:Envelope>'''
    
    headers = {'Content-Type': 'text/xml;charset=UTF-8'}
    
    retries = 0

    while retries < max_retries:
        try:
            # Usando aiohttp para a requisição assíncrona
            async with aiohttp.ClientSession() as session:
                async with session.post(url, data=payload, headers=headers) as response:
                    # Verifica se a resposta foi bem-sucedida
                    response.raise_for_status()

                    # Converte a resposta XML para dicionário Python
                    response_text = await response.text()
                    parsed_response = xmltodict.parse(response_text)

                    # Retorna o dicionário da resposta
                    return parsed_response
        
        except aiohttp.ClientError as e:
            print(f"Tentativa {retries + 1} falhou para a ordem {instDesignDef}: {e}")
            retries += 1
            if retries < max_retries:
                print(f"Aguardando {retry_delay} segundos antes de tentar novamente...")
                await asyncio.sleep(retry_delay)
            else:
                print(f"Erro na consulta da API WFM básica para ordem: {instDesignDef} após {max_retries} tentativas.")
                raise


# GAT\backend\services\interpretador.py:
from dotenv import load_dotenv
import os
import mysql.connector
import aiohttp
import asyncio
import xmltodict
import logging
import json
import re
from wfm_basico import consultaWFM_basico
from wfm_basico import consultaWFM_basico2
from wfm_full import consultaWFM_full
from design_ac import localiza_design_acesso
from valida_repetido import validar_repetido

# Carregar variáveis de ambiente do arquivo .env
load_dotenv()

# Configurando o log
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Conexão com o banco de dados
def get_mysql_connection():
    try:
        conn = mysql.connector.connect(
            host=os.getenv("DB_HOST"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD"),
            database=os.getenv("DB_NAME")
        )
        cursor_mysql = conn.cursor()
        cursor_mysql.execute("SET lc_time_names = 'pt_BR';")
        cursor_mysql.close()
        return conn
    except Exception as e:
        logging.error(f"Erro ao conectar no MySQL: {str(e)}")
        return None

def capturar_ordem(respWFMBasico):
    try:
        # Extrai o item workOrderItem do dicionário
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        
        # Se work_order_item for uma lista, pegue o primeiro item, senão, use o próprio dicionário
        if isinstance(work_order_item, list) and len(work_order_item) > 0:
            ordem = work_order_item[0].get("wor1:ID", "").split(":")[0]
        elif isinstance(work_order_item, dict):
            ordem = work_order_item.get("wor1:ID", "").split(":")[0]
        else:
            ordem = "Ainda não mapeado"

        return ordem

    except Exception as e:
        logging.error(f"Erro ao capturar número da ordem: {e}")
        return "Ainda não mapeado"

# Função para capturar o numero do protocolo:
def capturar_protocolo(respWFMFull):
    try:
        protocolo = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:orderProtocol", "Ainda não mapeado")
        return protocolo
    except Exception as e:
        logging.error(f"Erro ao capturar o numero do protocolo: {e}")

# Função para capturar data e hora da abertura da ordem:
def capturar_data_hora_abertura(respWFMFull):
    dataHoracriacaoBruta = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:dateOfSale", "Ainda não mapeado")
    try:
        # Tenta dividir a string no formato esperado (data e hora separadas por "T")
        dataCompleta, horaCompleta = dataHoracriacaoBruta.split('T')
        ano, mes, dia = dataCompleta.split('-')
        data_abertura = f"{ano}/{mes}/{dia}"
        horaCompleta = horaCompleta.split('-')[0]  # Remove o fuso horário se existir
        hora, minuto, segundoComFração = horaCompleta.split(':')
        segundo = round(float(segundoComFração))
        segundo = f"{segundo:02d}"
        hora_abertura = f"{hora}:{minuto}:{segundo}"
        return data_abertura, hora_abertura
    except (ValueError, AttributeError):
        # Caso o formato não seja o esperado, retorna valores padrão
        if not dataHoracriacaoBruta:
            return "Data inválida", "Hora inválida"

# Função para capturar nome do cliente
def capturar_nome_cliente(respWFMFull):
    try:
        nome =  respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:customer", {}).get("get:Individual", {}).get("get:name", "Ainda não mapeado") if isinstance(
                respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:customer", {}).get("get:Individual", {}).get("get:name", []), list) else "Ainda não mapeado"
        return nome
    except Exception as e:
        logging.error(f"Erro ao capturar nome do cliente: {e}")

# Função para capturar documento do cliente:
def capturar_documento_cliente(respWFMFull):
    try:
        documento = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:customer", {}).get("get:documentNumber", "Ainda não mapeado") if isinstance(
                    respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:customer", {}).get("get:documentNumber", []), list) else "Ainda não mapeado"
        return documento
    except Exception as e:
        logging.error(f"Erro ao capturar documento do cliente: {e}")
    

# Função para capturar segmento do cliente
def capturar_segmento_cliente(respWFMFull):
    try:
        segmento = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:customer", {}).get("get:customerSegment", "Ainda não mapeado") if isinstance(
                   respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:customer", {}).get("get:customerSegment", []), list) else "Ainda não mapeado"
        return segmento
    except Exception as e:
        logging.error(f"Erro ao capturar o segmento do cliente: {e}")

# Função para capturar rank do cliente
def capturar_rank_cliente(respWFMFull):
    try:
        rank = (respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:customer", {}).get("get:customerRank") or
               respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:customer", {}).get("get:customerRank", "Ainda não mapeado"))
        return rank
    except Exception as e:
        logging.error(f"Erro ao captuar o rank do cliente: {e}")

# Função para capturar o nomero completo da ordem:
def capturar_ordem_full(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        ordem_full = (work_order_item[0].get("wor1:ID", "Ainda não mapeado") if isinstance(
                     work_order_item := respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None), list) else
                     work_order_item.get("wor1:ID", "Ainda não mapeado") if isinstance(
                     work_order_item, dict)  else "Ainda não mapeado")
        return ordem_full
    except Exception as e:
        logging.error(f"Erro ao capturar o valor da ordem completa: {e}")

# Função para capturar sequencia da ordem:
def capturar_sequencia(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        sequencia = (work_order_item[0].get("wor1:sequence", "Ainda não mapeado") if isinstance(
                    work_order_item := respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None), list) else
                    work_order_item.get("wor1:sequence", "Ainda não mapeado") if isinstance(
                    work_order_item, dict)  else "Ainda não mapeado")
        return sequencia
    except Exception as e:
        logging.error(f"Erro ao capturar sequencia: {e}")

# Função para capturar código da rua:
def capturar_codigo_rua(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        codigo_rua = (work_order_item[0].get("wor1:place", {}).get("wor1:streetCode", "Ainda não mapeado") if isinstance(
                     work_order_item := respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None), list) else
                     work_order_item.get("wor1:place", {}).get("wor1:streetCode", "Ainda não mapeado") if isinstance(
                     work_order_item, dict) else "Ainda não mapeado")
        return codigo_rua
    except Exception as e:
        logging.error(f"Erro ao capturar código da rua: {e}")

# Função para capturar micro_area:
def capturar_micro_area(respWFMFull):
    try:
        micro_area = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:BusinessInteractionLocationSpecifiesThePlaceFor", {}).get("get:Place", {}).get("get:microarea", "Ainda não mapeado")
        return micro_area
    except Exception as e:
        logging.error(f"Erro ao capturar micro área: {e}")

# Função para capturar acronimo:
def capturar_acronimo(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        acronimo = (work_order_item[0].get("wor1:WorkOrderItemInvolvesWorkSpec", {}).get("wor1:specificationAcronym", "Ainda não mapeado") if isinstance(
                   work_order_item := respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None), list) else
                   work_order_item.get("wor1:WorkOrderItemInvolvesWorkSpec", {}).get("wor1:specificationAcronym", "Ainda não mapeado") if isinstance(
                   work_order_item, dict) else "Ainda não mapeado")
        return acronimo
    except Exception as e:
        logging.error(f"Erro ao capturar acrônimo: {e}")

# Função para capturar rede de acesso:
def capturar_rede_acesso(respWFMFull):
    try:
        rede_acesso = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:BusinessInteractionLocationSpecifiesThePlaceFor", {}).get("get:Place", {}).get("get:networkOwner", "Ainda não mapeado")
        return rede_acesso
    except Exception as e:
        logging.error(f"Erro ao capturar rede de acesso: {e}")

# Função para capturar tecnologia de acesso:
def capturar_tecnologia(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        tecnologia = (work_order_item[0].get("wor1:place", {}).get("wor1:mediaType", "Ainda não mapeado") if isinstance(
                     work_order_item, list) else
                     work_order_item.get("wor1:place", {}).get("wor1:mediaType", "Ainda não mapeado") if isinstance(
                     work_order_item, dict) else "Ainda não mapeado")
        return tecnologia
    except Exception as e:
        logging.error(f"Erro ao capturar tecnologia: {e}")

# Função para capturar tipo da ordem:
def capturar_tipo_ordem(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        tipo_ordem = (work_order_item[0].get("wor1:WorkOrderItemInvolvesWorkSpec", {}).get("wor1:specificationDescription", [])[0].get("wor1:value", "Ainda não mapeado") if isinstance(
                     work_order_item, list) else 
                     work_order_item.get("wor1:WorkOrderItemInvolvesWorkSpec", {}).get("wor1:specificationDescription", [])[0].get("wor1:value", "Ainda não mapeado") if isinstance(
                     work_order_item, dict) else "Ainda não mapeado")
        return tipo_ordem
    except Exception as e:
        logging.error(f"Erro ao capturar tipo da ordem: {e}")

# Função para capturar produto com defeito:
def capturar_produto(respWFMBasico=None, respWFMFull=None):
    try:
        # Inicializa a variável de retorno com um valor padrão
        produto = "Ainda não mapeado"

        # Verifica se respWFMBasico foi fornecido e tenta extrair o valor
        if respWFMBasico:
            work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
            if isinstance(work_order_item, dict):
                work_spec = work_order_item.get("wor1:WorkOrderItemInvolvesWorkSpec", {}).get("wor1:specificationDescription", [])
                if isinstance(work_spec, list) and len(work_spec) > 1:
                    produto = work_spec[1].get("wor1:value", "Ainda não mapeado")

        # Verifica se respWFMFull foi fornecido e tenta extrair o valor
        if respWFMFull:
            work_order_item = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderItemInvolvesWorkSpec", {}).get("get:specificationDescription", [])
            if isinstance(work_order_item, list) and len(work_order_item) > 1:
                produto = work_order_item[1].get("get:value", "Ainda não mapeado")
        return produto
    except Exception as e:
        logging.error(f"Erro ao capturar produto: {e}")
        return "Ainda não mapeado"

# Função para capturar detalhe da ordem:
def capturar_detalhe(respWFMFull):
    try:
        detalhe = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:detail", "Ainda não mapeado")
        return detalhe
    except Exception as e:
        logging.error(f"Erro ao capturar detalhe: {e}")

# Função para capturar status da ordem:
def capturar_situacao(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        situacao = (work_order_item[0].get("wor1:status", "Ainda não mapeado") if isinstance(
                   work_order_item := respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None), list) else
                   work_order_item.get("wor1:status", "Ainda não mapeado") if isinstance(
                   work_order_item, dict) else "Ainda não mapeado")
        return situacao
    except Exception as e:
        logging.error(f"Erro ao capturar situação: {e}")

# Função para capturar motivo da ordem:
def capturar_motivo_ordem(respWFMFull):
    try:
        motivo_ordem = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:statusReason", "Ainda não mapeado")
        return motivo_ordem
    except Exception as e:
        logging.error(f"Erro ao capturar motivo da ordem: {e}")

# Função para capturar motivo do cancelamento:
def capturar_motivo_cancelamento(respWFMFull):
    try:
        motivo_cancelamento = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:WorkOrderItemInvolvesWork", {}).get("get:notDoneReason", "Ainda não mapeado")
        return motivo_cancelamento
    except Exception as e:
        logging.error(f"Erro ao capturar motivo cancelamento: {e}")

# Função para capturar endereço do produto:
def capturar_endereco(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        endereco = (work_order_item[0].get("wor1:place", {}).get("wor1:streetName", "Ainda não mapeado") if isinstance(work_order_item, list) else
                   work_order_item.get("wor1:place", {}).get("wor1:streetName", "Ainda não mapeado") if isinstance(work_order_item, dict) else
                   "Ainda não mapeado")
        return endereco
    except Exception as e:
        logging.error(f"Erro ao capturar o endereço: {e}")

def capturar_numero(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        numero = (work_order_item[0].get("wor1:place", {}).get("wor1:streetNrFirst", "Ainda não mapeado") if isinstance(
                 work_order_item, list) else
                 work_order_item.get("wor1:place", {}).get("wor1:streetNrFirst", "Ainda não mapeado") if isinstance(
                 work_order_item, dict) else "Ainda não mapeado")
        return numero
    except Exception as e:
        logging.error(f"Erro ao capturar numero predial: {e}")

def capturar_complemento(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        complemento = (work_order_item[0].get("wor1:place", {}).get("wor1:complement", "Ainda não mapeado") if isinstance(
                      work_order_item, list) else
                      work_order_item.get("wor1:place", {}).get("wor1:complement", "Ainda não mapeado") if isinstance(
                      work_order_item, dict) else "Ainda não mapeado")
        return complemento
    except Exception as e:
        logging.error(f"Erro ao capturar complemento: {e}")

def capturar_cep(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        cep = (work_order_item[0].get("wor1:place", {}).get("wor1:postcode", "Ainda não mapeado") if isinstance(work_order_item, list) else work_order_item.get("wor1:place", {}).get("wor1:postcode", "Ainda não mapeado") if isinstance(work_order_item, dict) else "Ainda não mapeado")
        return cep
    except Exception as e:
        logging.error(f"Erro ao capturar CEP: {e}")

def capturar_bairro(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        bairro = (work_order_item[0].get("wor1:place", {}).get("wor1:neighborhood", "Ainda não mapeado") if isinstance(
                 work_order_item, list) else
                 work_order_item.get("wor1:place", {}).get("wor1:neighborhood", "Ainda não mapeado") if isinstance(
                 work_order_item, dict) else "Ainda não mapeado")
        return bairro
    except Exception as e:
        logging.error(f"Erro ao capturar bairro: {e}")

def capturar_cidade(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        cidade = (work_order_item[0].get("wor1:place", {}).get("wor1:city", "Ainda não mapeado") if isinstance(work_order_item, list) else work_order_item.get("wor1:place", {}).get("wor1:city", "Ainda não mapeado") if isinstance(work_order_item, dict) else "Ainda não mapeado")
        return cidade
    except Exception as e:
        logging.error(f"Erro ao capturar cidade: {e}")

def capturar_estado(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        estado = (work_order_item[0].get("wor1:place", {}).get("wor1:stateOrProvince", "Ainda não mapeado") if isinstance(
                 work_order_item, list) else
                 work_order_item.get("wor1:place", {}).get("wor1:stateOrProvince", "Ainda não mapeado") if isinstance(
                 work_order_item, dict) else "Ainda não mapeado")
        return estado
    except Exception as e:
        logging.error(f"Erro ao capturar estado: {e}")

def capturar_coordenadas(cep):
    try:
        posicao_X, posicao_Y = None, None
        
        conn = get_mysql_connection()
        if conn is None:
            return None, None

        cursor = conn.cursor(dictionary=True)

        try:
            # Query para buscar os valores da tabela
            query = """
            SELECT GA_XA_LONGITUDE, GA_XA_LATITUDE 
            FROM GTEO.ETA_LATITUDE_LONGITUDE 
            WHERE GA_ZIP = %s
            """
            cursor.execute(query, (cep,))
            result = cursor.fetchone()

            # Se o CEP foi encontrado
            if result:
                posicao_X = result['GA_XA_LATITUDE']
                posicao_Y = result['GA_XA_LONGITUDE']

        except mysql.connector.Error as e:
            logging.error(f"Erro ao executar query: {e}")
        finally:
            # Fechar o cursor e a conexão
            cursor.close()
            conn.close()

        return posicao_X, posicao_Y

    except Exception as e:
        logging.error(f"Erro ao capturar coordenadas: {e}")
        return None, None
    
def capturar_cluster_regional(cidade):
    try:
        # Conectar ao banco de dados MySQL
        conn = get_mysql_connection()
        if conn is None:
            return None, None, None
        
        cursor = conn.cursor(dictionary=True)

        try:
            # Query para buscar os valores da tabela
            query = """
            SELECT CLUSTER, REGIONAL 
            FROM GTEO.tb_cad_cidades_cluster_regionais
            WHERE CIDADE = %s
            """
            
            cursor.execute(query, (cidade,))
            result = cursor.fetchone()
            
            # Se a cidade foi encontrada
            if result:
                cluster = str(result['CLUSTER'])
                regional = str(result['REGIONAL'])
            else:
                cluster, regional = None, None

        except mysql.connector.Error as e:
            logging.error(f"Erro ao executar query: {e}")
        finally:
            # Fechar o cursor e a conexão
            cursor.close()
            conn.close()

        return cluster, regional
    
    except Exception as e:
        logging.error(f"Erro ao capturar cluster e regional: {e}")
        return None, None

def capturar_id_fibra(respWFMFull):
    try:
        id_fibra = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:customerFacingServiceAtomic", {}).get("get:serviceId", "Ainda não mapeado") if isinstance(
                   respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:customerFacingServiceAtomic", {}).get("get:serviceId", []), list) else "Ainda não mapeado"
        return id_fibra
    except Exception as e:
        logging.error(f"Erro ao capturar id fibra: {e}")

def capturar_id_ont(respWFMFull):
    try:
        id_ont = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:physicalResourceAssociated", {}).get("get:cabinet", {}).get("get:physicalDeviceAtomic", {}).get("get:opticalTerminalCode", "Ainda não mapeado")
        return id_ont
    except Exception as e:
        logging.error(f"Erro ao capturar id ont: {e}")

def capturar_cnl(respWFMBasico):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        cnl = (work_order_item[0].get("wor1:place", {}).get("wor1:cnl", "Ainda não mapeado") if isinstance(
              work_order_item, list) else
              work_order_item.get("wor1:place", {}).get("wor1:cnl", "Ainda não mapeado") if isinstance(
              work_order_item, dict) else "Ainda não mapeado")
        return cnl
    except Exception as e:
        logging.error(f"Erro ao capturar cnl: {e}")

def capturar_es(respWFMFull):
    try:
        es = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:BusinessInteractionLocationSpecifiesThePlaceFor", {}).get("get:Place", {}).get("get:centralOffice", "Ainda não mapeado")
        return es
    except Exception as e:
        logging.error(f"Erro ao capturar es: {e}")

def capturar_at(rede_acesso,respWFMFull):
    try:
        if rede_acesso in ['VIVO1', 'VIVO2']:
            at = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:BusinessInteractionLocationSpecifiesThePlaceFor", {}).get("get:Place", {}).get("get:telephonicArea", "Ainda não mapeado")
        elif rede_acesso in ['FIBRASIL', 'ATC']:
            at = None
        return at
    except Exception as e:
        logging.error(f"Erro ao capturar at: {e}")

def capturar_cto_tipo_end(respWFMFull):
    try:
        cto_tipo_end = (respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:physicalResourceAssociated", {}).get("get:cabinet", {}).get("get:terminalBox", [{}])[0].get("get:resourceAddress", {}).get("get:streetType") or
                       respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:physicalResourceAssociated", {}).get("get:cabinet", {}).get("get:terminalBox", [{}])[1].get("get:resourceAddress", {}).get("get:streetType", "Erro"))
        return cto_tipo_end
    except Exception as e:
        logging.error(f"Erro ao capturar cto tipo end: {e}")
        return "Erro"

def capturar_cto_nome_end(respWFMFull):
    try:
        cto_nome_end = (respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:physicalResourceAssociated", {}).get("get:terminalBox", [{}])[0].get("get:resourceAddress", {}).get("get:streetName") or
                       respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:physicalResourceAssociated", {}).get("get:cabinet", {}).get("get:terminalBox", [{}])[1].get("get:resourceAddress", {}).get("get:streetName", "Erro"))
        return cto_nome_end
    except Exception as e:
        logging.error(f"Erro ao capturar cto nome end: {e}")
        return "Erro"

def capturar_cto_num_end(respWFMFull):
    try:
        cto_end_num = (respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:physicalResourceAssociated", {}).get("get:terminalBox", [{}])[0].get("get:resourceAddress", {}).get("get:streetNrFirst") or
                       respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:physicalResourceAssociated", {}).get("get:cabinet", {}).get("get:terminalBox", [{}])[1].get("get:resourceAddress", {}).get("get:streetNrFirst", "Erro"))
        return cto_end_num
    except Exception as e:
        logging.error(f"Erro ao capturar cto num end: {e}")
        return "Erro"

def capturar_cto_id_caixa(respWFMFull):
    try:
        cto_id_caixa = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:physicalResourceAssociated", {}).get("get:terminalBox", [{}])[0].get("get:objectID", "Ainda não mapeado")
        return cto_id_caixa
    except Exception as e:
        logging.error(f"Erro ao capturar cto id caixa: {e}")

def capturar_armario_olt(rede_acesso, respWFMBasico, respWFMFull):
    try:
        work_order_item = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
        armario_olt1 = "Ainda não mapeado"  # Definido um valor padrão para garantir que a variável sempre exista
        armario_olt = ""

        if rede_acesso is None:
            armario_olt = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("wor1:place", {}).get("wor1:cabinetName", "Ainda não mapeado")
        elif rede_acesso == 'VIVO1':
            armario_olt_data = respWFMFull.get('soapenv:Envelope', {}).get('soapenv:Body', {}).get('wor:getFullWorkOrderItemOut', {}).get('wor1:workOrderItem', {})
            
            # Se não encontrar o valor desejado, tenta outros caminhos
            if not armario_olt:
                armario_olt = (
                    armario_olt_data.get('get:workOrder', {}).get('get:WorkOrderComprisedOf', {}).get('get:physicalResourceAssociated', {}).get('get:cabinet', {}).get('get:HasShelves', [{}])[0].get('get:objectID') or
                    armario_olt_data.get('get:workOrder', {}).get('get:WorkOrderComprisedOf', {}).get('get:BusinessInteractionLocationSpecifiesThePlaceFor', {}).get('get:Place', {}).get('get:PlacePhysicalResourceAssoc', {}).get('get:Cabinet', {}).get('get:classification') or
                    armario_olt_data.get('get:workOrder', {}).get('get:WorkOrderComprisedOf', {}).get('get:BusinessInteractionLocationSpecifiesThePlaceFor', {}).get('get:Place', {}).get('get:PlacePhysicalResourceAssoc', {}).get('get:Cabinet', {}).get('get:HasShelves', [{}])[0].get('get:objectID') or
                    armario_olt_data.get('get:workOrder', {}).get('get:WorkOrderComprisedOf', {}).get('get:physicalResourceAssociated', {}).get('get:physicalDeviceAtomic', {}).get('get:name', "Ainda não mapeado")
                    # armario_olt_data.get('get:workOrder', {}).get('get:WorkOrderComprisedOf', {}).get('get:physicalResourceAssociated', {}).get('get:physicalDeviceAtomic', {}).get('get:model')
                )
        elif rede_acesso in ['VIVO2', 'FIBRASIL', 'ATC']:
            # Extrai armario_olt1 de maneira segura (trata listas e dicionários)
            if isinstance(work_order_item, list):
                armario_olt1 = work_order_item[0].get("wor1:place", {}).get("wor1:cabinetName", "Ainda não mapeado")
            elif isinstance(work_order_item, dict):
                armario_olt1 = work_order_item.get("wor1:place", {}).get("wor1:cabinetName", "Ainda não mapeado")

        # Extrai armario_olt2 do respWFMFull
        armario_olt2 = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {})

        # Combina armario_olt1 e armario_olt2 se armario_olt ainda estiver vazio
        armario_olt = (
            armario_olt if armario_olt else
            armario_olt1 or
            armario_olt2.get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:BusinessInteractionLocationSpecifiesThePlaceFor", {}).get("get:Place", {}).get("get:PlacePhysicalResourceAssoc", {}).get("get:Cabinet", {}).get("get:classification", "Ainda não mapeado")
        )

        return armario_olt
    except Exception as e:
        logging.error(f"Erro ao capturar armario olt: {e}")
        return "Erro"

def capturar_vlan_rede_rin(respWFMFull):
    try:
        vlan_rede_rin = respWFMFull.get("soapenv:Envelope",{}).get("soapenv:Body",{}).get("wor:getFullWorkOrderItemOut",{}).get("wor1:workOrderItem",{}).get("get:workOrder",{}).get("get:WorkOrderComprisedOf",{}).get("get:physicalResourceAssociated",{}).get("get:cabinet",{}).get("get:terminationPoint",{}).get("get:networkId", "Ainda não mapeado")
        return vlan_rede_rin
    except Exception as e:
        logging.error(f"Erro ao capturar vlan de rede rin: {e}")

def capturar_vlan_usuario(respWFMFull):
    try:
        vlan_usuario = respWFMFull.get("soapenv:Envelope",{}).get("soapenv:Body",{}).get("wor:getFullWorkOrderItemOut",{}).get("wor1:workOrderItem",{}).get("get:workOrder",{}).get("get:WorkOrderComprisedOf",{}).get("get:physicalResourceAssociated",{}).get("get:cabinet",{}).get("get:terminationPoint",{}).get("get:clientId", "Ainda não mapeado")
        return vlan_usuario
    except Exception as e:
        logging.error(f"Erro ao capturar vlan usuario: {e}")

def capturar_vlan_multicast(respWFMFull):
    try:
        vlan_multicast = respWFMFull.get("soapenv:Envelope",{}).get("soapenv:Body",{}).get("wor:getFullWorkOrderItemOut",{}).get("wor1:workOrderItem",{}).get("get:workOrder",{}).get("get:WorkOrderComprisedOf",{}).get("get:physicalResourceAssociated",{}).get("get:cabinet",{}).get("get:terminationPoint",{}).get("get:multicastId", "Ainda não mapeado")
        return vlan_multicast
    except Exception as e:
        logging.error(f"Erro ao capturar vlan multicast: {e}")

def capturar_vlan_audiencia(respWFMFull):
    try:
        vlan_audiencia = respWFMFull.get("soapenv:Envelope",{}).get("soapenv:Body",{}).get("wor:getFullWorkOrderItemOut",{}).get("wor1:workOrderItem",{}).get("get:workOrder",{}).get("get:WorkOrderComprisedOf",{}).get("get:physicalResourceAssociated",{}).get("get:cabinet",{}).get("get:terminationPoint",{}).get("get:audienceId", "Ainda não mapeado")
        return vlan_audiencia
    except Exception as e:
        logging.error(f"Erro ao capturar vlan audiencia: {e}")

def capturar_vlan_unicast(respWFMFull):
    try:
        vlan_unicast = respWFMFull.get("soapenv:Envelope",{}).get("soapenv:Body",{}).get("wor:getFullWorkOrderItemOut",{}).get("wor1:workOrderItem",{}).get("get:workOrder",{}).get("get:WorkOrderComprisedOf",{}).get("get:physicalResourceAssociated",{}).get("get:cabinet",{}).get("get:terminationPoint",{}).get("get:unicastId", "Ainda não mapeado")
        return vlan_unicast
    except Exception as e:
        logging.error(f"Erro ao capturar vlan unicast: {e}")

def capturar_olt_fabricante(respWFMFull):
    try:
        olt_fabricante = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:physicalResourceAssociated", {}).get("get:cabinet", {}).get("get:physicalDeviceAtomic", {}).get("get:manufacturer", "Ainda não mapeado")
        return olt_fabricante
    except Exception as e:
        logging.error(f"Erro ao capturar olt fabricante: {e}")

def capturar_olt_slot(respWFMFull):
    try:
        olt_slot = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:physicalResourceAssociated", {}).get("get:cabinet", {}).get("get:HasShelves", [{}])[0].get("get:slotId", "Ainda não mapeado")
        return olt_slot
    except Exception as e:
        logging.error(f"Erro ao capturar olt slot: {e}")

def capturar_olt_porta(respWFMFull):
    try:
        olt_porta = respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:physicalResourceAssociated", {}).get("get:cabinet", {}).get("get:HasShelves", [{}])[0].get("get:portId", "Ainda não Mapeado")
        return olt_porta
    except Exception as e:
        logging.error(f"Erro ao capturar olt porta: {e}")
    
def capturar_posicao_fisica(rede_acesso, tecnologia, respWFMBasico, respWFMFull):
    posicao_fisica = "Ainda não mapeado"  # Inicializa com valor padrão

    if rede_acesso == 'VIVO1' and tecnologia == 'METALICO':
        try:
            # Implementação específica para essa combinação de rede e tecnologia
            posicao_fisica = {
                "id_fibra":       None,
                "id_ont":         None,
                "cnl":            capturar_cnl(respWFMBasico),
                "es":             capturar_es(respWFMFull),
                "at":             capturar_at(rede_acesso, respWFMFull),
                "cto_tipo_end":   capturar_cto_tipo_end(respWFMFull),
                "cto_nome_end":   capturar_cto_nome_end(respWFMFull),
                "cto_num_end":    capturar_cto_num_end(respWFMFull),
                "cto_id_caixa":   None,
                "armario_olt":    capturar_armario_olt(rede_acesso, respWFMBasico, respWFMFull),
                "shelf":          None,
                "vlan_rede_rin":  None,
                "vlan_usuario":   None,
                "vlan_multicast": None,
                "vlan_audiencia": None,
                "vlan_unicast":   None,
                "olt_fabricante": "MA5600",
                "olt_slot":       None,
                "olt_porta":      None,
                "cabo":           None,
                "spliter_1":      None,
                "spliter_2":      None,
                "fibra_porta":    None, 
                "bras":           None,
            }
        except Exception as e:
            logging.error(f"Erro ao capturar Posição Física VIVO1 - Metálico: {e}")
            posicao_fisica = "Erro ao capturar posição"

    elif rede_acesso == 'VIVO2' and tecnologia == 'METALICO':
        try:
            posicao_fisica = {}

            summary = respWFMBasico.get("soapenv:Envelope", {}).get("soapenv:Body").get("wor:findWorkOrderItemOut").get("wor1:workOrderItem").get("wor1:physicalResourceSummary", "Ainda não mapeado")
            
            if summary == "TT Light : Sim":
                return

            array_summary_total = summary.split(', ')

            array_summary_final = [item.strip() for item in array_summary_total.pop().split(' ')]

            array_summary_primeiro = array_summary_total.pop(0) if array_summary_total else ""

            valor_regex = re.findall(r"(\b\w+\b)\s*:\s*(\w+|\d+,\d*|\w+,\d+|\d+,\w+| )", array_summary_primeiro)

            posicao_fisica_temp = {key.strip(): value.strip() for key, value in valor_regex}

            for item in array_summary_total:
                if ':' in item:
                    key, value = [i.strip() for i in item.split(':', 1)]
                    if key:
                        posicao_fisica_temp[key] = value

            for item in array_summary_final:
                if ':' in item:
                    key, value = [i.strip() for i in item.split(':', 1)]
                    if key:
                        posicao_fisica_temp[key] = value

            posicao_fisica_temp = {k: v for k, v in posicao_fisica_temp.items() if k and v}

            posicao_fisica = {
                "id_fibra":       None,
                "id_ont":         None,
                "cnl":            capturar_cnl(respWFMBasico),
                "es":             capturar_es(respWFMFull),
                "at":             capturar_at(rede_acesso, respWFMFull),
                "cto_tipo_end":   None,
                "cto_nome_end":   None,
                "cto_num_end":    None,
                "cto_id_caixa":   None,
                "armario_olt":    posicao_fisica_temp['armario'] if "armario" in posicao_fisica_temp else None,
                "shelf":          posicao_fisica_temp['shelf'] if "shelf" in posicao_fisica_temp else None,
                "vlan_rede_rin":  posicao_fisica_temp['rin'] if "rin" in posicao_fisica_temp else None,
                "vlan_usuario":   None,
                "vlan_multicast": None,
                "vlan_audiencia": None,
                "vlan_unicast":   None,
                "olt_fabricante": posicao_fisica_temp['vendor name'] if "vendor name" in posicao_fisica_temp else None,
                "olt_slot":       None,
                "olt_porta":      None,
                "cabo":           posicao_fisica_temp['Cabo'] if "Cabo" in posicao_fisica_temp else None,
                "spliter_1":      posicao_fisica_temp['Splitter_1n'] if "Splitter_1n" in posicao_fisica_temp else None,
                "spliter_2":      posicao_fisica_temp['Splitter_2n'] if "Splitter_2n" in posicao_fisica_temp else None,
                "fibra_porta":    posicao_fisica_temp['porta'] if "porta" in posicao_fisica_temp else None, 
                "bras":           None,
            }
            # print(f"posicao fisica", posicao_fisica_temp)
        
            return posicao_fisica
            # Implementação específica para essa combinação de rede e tecnologia

        except Exception as e:
            logging.error(f"Erro ao capturar Posição Física VIVO2 - Metálico: {e}")
            posicao_fisica = "Erro ao capturar posição"

    elif (rede_acesso == 'VIVO1' or rede_acesso == 'VIVO2') and tecnologia == 'GPON':
        try:
            posicao_fisica = {
                "id_fibra":       capturar_id_fibra(respWFMFull),
                "id_ont":         capturar_id_ont(respWFMFull),
                "cnl":            capturar_cnl(respWFMBasico),
                "es":             capturar_es(respWFMFull),
                "at":             capturar_at(rede_acesso, respWFMFull),
                "cto_tipo_end":   capturar_cto_tipo_end(respWFMFull),
                "cto_nome_end":   capturar_cto_nome_end(respWFMFull),
                "cto_num_end":    capturar_cto_num_end(respWFMFull),
                "cto_id_caixa":   capturar_cto_id_caixa(respWFMFull),
                "armario_olt":    capturar_armario_olt(rede_acesso, respWFMBasico, respWFMFull),
                "shelf":          None,
                "vlan_rede_rin":  capturar_vlan_rede_rin(respWFMFull),
                "vlan_usuario":   capturar_vlan_usuario(respWFMFull),
                "vlan_multicast": capturar_vlan_multicast(respWFMFull),
                "vlan_audiencia": capturar_vlan_audiencia(respWFMFull),
                "vlan_unicast":   capturar_vlan_unicast(respWFMFull),
                "olt_fabricante": capturar_olt_fabricante(respWFMFull),
                "olt_slot":       capturar_olt_slot(respWFMFull),
                "olt_porta":      capturar_olt_porta(respWFMFull),
                "cabo":           None,
                "spliter_1":      None,
                "spliter_2":      None,
                "fibra_porta":    None, 
                "bras":           None,
            }
        except Exception as e:
            logging.error(f"Erro ao capturar Posição Física VIVO1 ou VIVO2 - GPON: {e}")
            posicao_fisica = "Erro ao capturar posição"

    elif rede_acesso in ['FIBRASIL', 'ATC'] and tecnologia == 'GPON':
        try:
            # Implementação específica para FIBRASIL e ATC com GPON
            posicao_fisica = {
                "id_fibra":       capturar_id_fibra(respWFMFull),
                "id_ont":         capturar_id_ont(respWFMFull),
                "cnl":            capturar_cnl(respWFMBasico),
                "es":             capturar_es(respWFMFull),
                "at":             capturar_at(rede_acesso, respWFMFull),
                "cto_tipo_end":   capturar_cto_tipo_end(respWFMFull),
                "cto_nome_end":   capturar_cto_nome_end(respWFMFull),
                "cto_num_end":    capturar_cto_num_end(respWFMFull),
                "cto_id_caixa":   capturar_cto_id_caixa(respWFMFull),
                "armario_olt":    capturar_armario_olt(rede_acesso, respWFMBasico, respWFMFull),
                "shelf":          None,
                "vlan_rede_rin":  capturar_vlan_rede_rin(respWFMFull),
                "vlan_usuario":   capturar_vlan_usuario(respWFMFull),
                "vlan_multicast": capturar_vlan_multicast(respWFMFull),
                "vlan_audiencia": capturar_vlan_audiencia(respWFMFull),
                "vlan_unicast":   capturar_vlan_unicast(respWFMFull),
                "olt_fabricante": capturar_olt_fabricante(respWFMFull),
                "olt_slot":       capturar_olt_slot(respWFMFull),
                "olt_porta":      capturar_olt_porta(respWFMFull),
                "cabo":           None,
                "spliter_1":      None,
                "spliter_2":      None,
                "fibra_porta":    None, 
                "bras":           None,
            }
        except Exception as e:
            logging.error(f"Erro ao capturar Posição Física FIBRASIL ou ATC - GPON: {e}")
            posicao_fisica = "Erro ao capturar posição"

    # Retorna a posição física, que foi inicializada em todos os casos
    return posicao_fisica

# def capturar_produtos_contratados(respWFMBasico):
def capturar_produtos_contratados(respWFMBasico):
    try:
        produtos_contratados = {}

        def adicionar_produto(produto):
            product_name = produto.get('wor1:productSpecification', {}).get('wor1:name', '').replace(" ", "_").lower()
            produtos_contratados[product_name] = {
                'id': produto.get('wor1:ID', None),
                'instancia': produto.get('wor1:serviceId') if product_name == 'linha_telefônica' else None,
                'designador': produto.get('wor1:serviceId') if product_name != 'linha_telefônica' else None,
                'provisioning': produto.get('wor1:provisioningCode', None),
                'tecnologia': produto.get('wor1:serviceTechnology', None),
                'acao': produto.get('wor1:productAction', None),
                'status': produto.get('wor1:productStatus', None),
            }

        # Acessa a lista de produtos envolvidos na resposta
        work_order_items = respWFMBasico.get('soapenv:Envelope', {}).get('soapenv:Body', {}).get('wor:findWorkOrderItemOut', {}).get('wor1:workOrderItem', [])
        
        if isinstance(work_order_items, list):
            for work_order_item in work_order_items:
                involved_products = work_order_item.get('wor1:involvesProduct', [])
                if isinstance(involved_products, list):
                    for product in involved_products:
                        adicionar_produto(product)
                elif isinstance(involved_products, dict):
                    adicionar_produto(involved_products)
        elif isinstance(work_order_items, dict):
            involved_products = work_order_items.get('wor1:involvesProduct', [])
            if isinstance(involved_products, list):
                for product in involved_products:
                    adicionar_produto(product)
            elif isinstance(involved_products, dict):
                adicionar_produto(involved_products)

        # Produtos padrão que devem existir
        produtos_padrao = ['linha_telefônica', 'banda_larga', 'tv_por_assinatura', 'acesso']

        for produto in produtos_padrao:
            produtos_contratados.setdefault(produto, {
                'id': None,
                'instancia': None,
                'designador': None,
                'provisioning': None,
                'tecnologia': None,
                'acao': None,
                'status': None,
            })

        return produtos_contratados
    except Exception as e:
        logging.error(f"Erro ao capturar produtos contratados: {e}")
        return {}

async def mapear_produtos_contratados(produtos_contratados):
    try:
        # Mapeando as variáveis desejadas dos produtos contratados
        instancia = produtos_contratados.get('linha_telefônica', {}).get('instancia', None)
        design_bl = produtos_contratados.get('banda_larga', {}).get('designador', None)
        design_tv = produtos_contratados.get('tv_por_assinatura', {}).get('designador', None)
        design_ac = produtos_contratados.get('acesso', {}).get('designador', None)

        # Se a banda larga existir, buscar o designador do acesso
        designBL = produtos_contratados.get('banda_larga', {}).get('designador', None)
        if designBL and not produtos_contratados['acesso']['designador']:
            design_ac = await localiza_design_acesso(designBL)
            produtos_contratados['acesso']['designador'] = design_ac

        return instancia, design_bl, design_tv, design_ac

    except KeyError as e:
        logging.error(f"Chave não encontrada ao mapear produtos contratados: {e}")
        return None, None, None, None
    except Exception as e:
        logging.error(f"Erro ao mapear produtos contratados: {e}")
        return None, None, None, None

async def capturar_repetido_7_15_30dias(instancia, design_bl):
    try:
        if design_bl:
            respWFMBasico2 = await consultaWFM_basico2(design_bl)
        else:
            respWFMBasico2 = await consultaWFM_basico2(instancia)

        if respWFMBasico2:
            respValidaRepetido = await validar_repetido(respWFMBasico2)
            if respValidaRepetido:
                repetido_7dias = respValidaRepetido.get('repetido_7dias', None)
                repetido_15dias = respValidaRepetido.get('repetido_15dias', None)
                repetido_30dias = respValidaRepetido.get('repetido_30dias', None)
                ordem_raiz = respValidaRepetido.get('numero_ordem_repetida', None)
                dif_dias = respValidaRepetido.get('diferenca_dias', None)
            else:
                repetido_7dias, repetido_15dias, repetido_30dias, ordem_raiz, dif_dias = None, None, None, None, None
        else:
            repetido_7dias, repetido_15dias, repetido_30dias, ordem_raiz, dif_dias = None, None, None, None, None

        return repetido_7dias, repetido_15dias, repetido_30dias, ordem_raiz, dif_dias
    except Exception as e:
        logging.error(f"Erro ao capturar repetido 7 15 30 dias: {e}")
        return None, None, None, None, None

def capturar_equipamentos(respWFMBasico):
    equipamentos = {}
    try:
        # Acessa o item 'workOrderItem', que pode ser uma lista (como no segundo tipo de ordem)
        work_order_items = respWFMBasico.get('soapenv:Envelope', {}).get('soapenv:Body', {}).get('wor:findWorkOrderItemOut', {}).get('wor1:workOrderItem', [])
        
        # Se for uma lista, iteramos sobre os itens
        if isinstance(work_order_items, list):
            for item in work_order_items:
                # Acessa 'involvesDevice' para capturar os dispositivos
                involves_device = item.get('wor1:involvesDevice', {})
                
                # Se 'involvesDevice' for um dicionário, captura os dados
                if isinstance(involves_device, dict):
                    role = involves_device.get('wor1:HasPhysicalDeviceRole', 'Ainda não mapeado')
                    equipamentos[role] = {
                        'serialNumber': involves_device.get('wor1:serialNumber', 'Ainda não mapeado'),
                        'macAddress': involves_device.get('wor1:macAddress', 'Ainda não mapeado')
                    }
        
        # Se for um dicionário (caso de apenas um item), captura o equipamento
        elif isinstance(work_order_items, dict):
            involves_device = work_order_items.get('wor1:involvesDevice', {})
            if isinstance(involves_device, dict):
                role = involves_device.get('wor1:HasPhysicalDeviceRole', 'Ainda não mapeado')
                equipamentos[role] = {
                    'serialNumber': involves_device.get('wor1:serialNumber', 'Ainda não mapeado'),
                    'macAddress': involves_device.get('wor1:macAddress', 'Ainda não mapeado')
                }
        else:
            logging.warning("Nenhum equipamento envolvido encontrado.")
    
    except Exception as e:
        logging.error(f"Erro ao capturar equipamentos: {e}")

    return equipamentos

# Função para estruturar o objeto resposta
def estrutura_resposta(ordem, sistema_origem, protocolo, data_abertura, hora_abertura, nome, documento, segmento, rank, ordem_full, sequencia, codigo_rua, micro_area, acronimo, rede_acesso, tecnologia, tipo_ordem, produto, detalhe, situacao, motivo_ordem, motivo_cancelamento, endereco, numero, complemento, cep, bairro, cidade, estado, posicao_X, posicao_Y, cluster, regional, posicao_fisica, produtos_contratados, repetido_7dias, repetido_15dias, repetido_30dias, ordem_raiz, dif_dias, equipamentos):
    try:
        ordem_servico = {
            "dados_ordem": {
                "ordem":          ordem,
                "sistema_origem": sistema_origem,
                "protocolo":      protocolo,
                "data_abertura":  data_abertura,
                "hora_abertura":  hora_abertura
            },
            "dados_cliente": {
                "nome":      nome,
                "documento": documento,
                "segmento":  segmento,
                "rank":      rank
            },
            "detalhe_ordem": {
                "ordem_full":          ordem_full,
                "sequencia":           sequencia, 
                "codigo_rua":          codigo_rua,
                "micro_area":          micro_area,
                "acronimo":            acronimo,
                "liberado":            "Ainda não mapeado",
                "rede_externa":        "Ainda não mapeado" ,#respWFMFull.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:getFullWorkOrderItemOut", {}).get("wor1:workOrderItem", {}).get("get:workOrder", {}).get("get:WorkOrderComprisedOf", {}).get("get:BusinessInteractionLocationSpecifiesThePlaceFor", {}).get("get:Place", {}).get("get:networkOwner", "Ainda não mapeado"),
                "rede_acesso":         rede_acesso,
                "tecnologia":          tecnologia,
                "tipo_ordem":          tipo_ordem,
                "produto":             produto, 
                "detalhe":             detalhe,
                "situacao":            situacao,
                "motivo_ordem":        motivo_ordem,
                "motivo_cancelamento": motivo_cancelamento,
                "endereco":            endereco,
                "numero":              numero,
                "complemento":         complemento,
                "cep":                 cep,
                "bairro":              bairro,
                "cidade":              cidade,
                "estado":              estado,
                "posicao_X":           posicao_X,
                "posicao_Y":           posicao_Y,
                "cluster":             cluster,
                "regional":            regional,
                "repetido_7dias":      repetido_7dias,
                "repetido_15dias":     repetido_15dias,
                "repetido_30dias":     repetido_30dias,
                "ordem_raiz":          ordem_raiz,
                "quant_dias":          dif_dias,
            },
            "posicao_fisica":       posicao_fisica,
            "produtos_contratados": produtos_contratados,
            "equipamentos":         equipamentos
        }
        return ordem_servico
    except Exception as e:
        logging.error(f"Erro ao criar objeto resposta: {e}")

# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Função para interpretar o XML da resposta SOAP
async def interpretar_xml(respWFMBasico, respWFMFull):
    ordem = capturar_ordem(respWFMBasico)
    sistema_origem = 'SIEBEL' if ordem.startswith('8-') else 'NEXT'
    protocolo = capturar_protocolo(respWFMFull)
    data_abertura, hora_abertura = capturar_data_hora_abertura(respWFMFull)
    nome = capturar_nome_cliente(respWFMFull)
    documento = capturar_documento_cliente(respWFMFull)
    segmento = capturar_segmento_cliente(respWFMFull)
    rank = capturar_rank_cliente(respWFMFull)
    ordem_full = capturar_ordem_full(respWFMBasico)
    sequencia = capturar_sequencia(respWFMBasico)
    codigo_rua = capturar_codigo_rua(respWFMBasico)
    micro_area = capturar_micro_area(respWFMFull)
    acronimo = capturar_acronimo(respWFMBasico)
    rede_acesso = capturar_rede_acesso(respWFMFull)
    tecnologia = capturar_tecnologia(respWFMBasico)
    tipo_ordem = capturar_tipo_ordem(respWFMBasico)
    produto = capturar_produto(respWFMBasico)
    detalhe = capturar_detalhe(respWFMFull)
    situacao = capturar_situacao(respWFMBasico)
    motivo_ordem = capturar_motivo_ordem(respWFMFull)
    motivo_cancelamento = capturar_motivo_cancelamento(respWFMFull)
    endereco = capturar_endereco(respWFMBasico)
    numero = capturar_numero(respWFMBasico)
    complemento = capturar_complemento(respWFMBasico)
    cep = capturar_cep(respWFMBasico)
    bairro = capturar_bairro(respWFMBasico)
    cidade = capturar_cidade(respWFMBasico)
    estado = capturar_estado(respWFMBasico)
    posicao_X, posicao_Y = capturar_coordenadas(cep)
    cluster, regional = capturar_cluster_regional(cidade)
    posicao_fisica = capturar_posicao_fisica(rede_acesso, tecnologia, respWFMBasico, respWFMFull)
    produtos_contratados = capturar_produtos_contratados(respWFMBasico)
    instancia, design_bl, design_tv, design_ac = await mapear_produtos_contratados(produtos_contratados)
    repetido_7dias, repetido_15dias, repetido_30dias, ordem_raiz, dif_dias = await capturar_repetido_7_15_30dias(instancia, design_bl)
    equipamentos = capturar_equipamentos(respWFMBasico)

    ordem_servico = estrutura_resposta(ordem, sistema_origem, protocolo, data_abertura, hora_abertura, nome, documento, segmento, rank, ordem_full, sequencia, codigo_rua, micro_area, acronimo, rede_acesso, tecnologia, tipo_ordem, produto, detalhe, situacao, motivo_ordem, motivo_cancelamento, endereco, numero, complemento, cep, bairro, cidade, estado, posicao_X, posicao_Y, cluster, regional, posicao_fisica, produtos_contratados, repetido_7dias, repetido_15dias, repetido_30dias, ordem_raiz, dif_dias, equipamentos)

    return ordem_servico


# Fluxo de execução principal
async def fluxo_execucao(ordemBD):
    # Etapa 1: Executar a consulta WFM Básico
    xml1 = await consultaWFM_basico(ordemBD)
    # print(f"xml1 = ", xml1)
    # Extraindo work_order_item corretamente
    work_order_item = xml1.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None)
    
    if xml1:
        # Etapa 2: Capturar ordem_full da resposta de xml1
        ordem_full = (work_order_item[0].get("wor1:ID", "Ainda não mapeado") if isinstance(work_order_item := xml1.get("soapenv:Envelope", {}).get("soapenv:Body", {}).get("wor:findWorkOrderItemOut", {}).get("wor1:workOrderItem", None), list) else work_order_item.get("wor1:ID", "Ainda não mapeado") if isinstance(work_order_item, dict) else "Ainda não mapeado")
        # print(ordem_full)
        
        if ordem_full != "Ainda não mapeado":
            # Etapa 3: Executar a consulta WFM Full com ordem_full
            xml2 = await consultaWFM_full(ordem_full)
            # print(f"xml2 = ", xml2)

            if xml2:
                # Etapa 4: Executar a função interpretar_xml
                bdinfo = await interpretar_xml(xml1, xml2)
    
                # Gravando a resposta no arquivo bdinfo.json
                with open('bdinfo.json', 'w', encoding='utf-8') as json_file:
                    json.dump(bdinfo, json_file, ensure_ascii=False, indent=4)

                # print("Response gravado em response.json")
                return bdinfo
                
            else:
                print(f"Falha ao obter a resposta completa de WFM Full para a ordem: {ordem_full}")
        else:
            print("Falha ao capturar o valor de ordem_full no XML1.")
    else:
        print("Falha ao obter a resposta básica de WFM.")


# # Para rodar o fluxo de execução
# ordemBD = "59984282"  # Substitua pelo valor da ordemBD
# ordemBD = "8-7F8SCS1Z"  # Substitua pelo valor da ordemBD
ordemBD = "61530596"  # Substitua pelo valor da ordemBD
asyncio.run(fluxo_execucao(ordemBD))
// backend/controllers/automacoesController.js
const { execFile, spawn } = require("child_process");
const path = require("path");
const { registrarLog } = require("../db/db");
const { getIo } = require("../server");

const io = getIo();

let coletandoOrdens = false;
let processoColeta = null;

const verificarPython = () => {
    return new Promise((resolve, reject) => {
        const pythonCheck = spawn("python", ["--version"]);

        pythonCheck.stdout.on("data", (data) => {
            console.log(`✅ Python encontrado: ${data.toString().trim()}`);
            resolve(true);
        });

        pythonCheck.stderr.on("data", (data) => {
            console.error(`❌ Erro ao verificar Python: ${data.toString().trim()}`);
            reject("Python não encontrado. Certifique-se de que está instalado e no PATH.");
        });

        pythonCheck.on("error", (err) => {
            console.error(`❌ Erro ao executar Python: ${err.message}`);
            reject("Erro ao executar o comando Python.");
        });
    });
};

const iniciarColetaOrdens = async (res) => {
    try {
        await verificarPython();
    } catch (error) {
        io.emit('coleta_status', { status: 'error', message: error });
        return res.status(500).json({ error: error });
    }

    if (coletandoOrdens) {
        io.emit('coleta_status', { status: 'info', message: 'A coleta já está em execução!' });
        return res.json({ message: "A coleta já está em execução!" });
    }

    coletandoOrdens = true;
    const scriptPath = path.join(__dirname, "../microservices/coleta_ordens.py");

    const executarColeta = () => {
        const pythonExecutable = process.platform === "win32" ? "python" : "python3";
        processoColeta = spawn(pythonExecutable, [scriptPath]);

        processoColeta.stdout.on("data", (data) => {
            const message = data.toString().trim();
            console.log(`✅ Saída: ${message}`);
            registrarLog(`Coleta: ${message}`);
            io.emit('coleta_status', { status: 'success', message: message });
        });

        processoColeta.stderr.on("data", (data) => {
            const errorMessage = data.toString().trim();
            console.error(`❌ Erro: ${errorMessage}`);
            registrarLog(`Erro na coleta: ${errorMessage}`);
            io.emit('coleta_status', { status: 'error', message: errorMessage });
        });

        processoColeta.on("close", (code) => {
            console.log(`⚠️ Coleta finalizada com código ${code}`);
            if (coletandoOrdens) {
                setTimeout(executarColeta, 5000);
            } else {
                io.emit('coleta_status', { status: 'info', message: 'Coleta finalizada.' });
            }
        });
    };

    executarColeta();
    io.emit('coleta_status', { status: 'info', message: 'Coleta de ordens iniciada!' });
    res.json({ message: "Coleta de ordens iniciada!" });
};

const pararColetaOrdens = (res) => {
    if (!coletandoOrdens || !processoColeta) {
        io.emit('coleta_status', { status: 'info', message: 'Nenhum processo de coleta está rodando.' });
        return res.json({ message: "Nenhum processo de coleta está rodando." });
    }

    processoColeta.kill();
    coletandoOrdens = false;
    io.emit('coleta_status', { status: 'info', message: 'Processo de coleta interrompido!' });
    res.json({ message: "Processo de coleta interrompido!" });
};

const enriquecerOrdens = async (req, res) => {
    try {
        const scriptPath = path.join(__dirname, "../microservices/enriquecimentos_ordens.py");

        io.emit("coleta_status", { status: "info", message: "🔄 Iniciando enriquecimento de ordens..." });

        const processo = spawn("python", [scriptPath]);

        let logs = "";

        // Captura saída padrão (stdout)
        processo.stdout.on("data", (data) => {
            const message = data.toString().trim();
            console.log(`LOG: ${message}`);
            logs += message + "\n";
            io.emit("coleta_status", { status: "success", message: message });
        });

        // Captura erros (stderr)
        processo.stderr.on("data", (data) => {
            const errorMessage = data.toString().trim();
            console.error(`ERRO: ${errorMessage}`);
            logs += "ERRO: " + errorMessage + "\n";
            io.emit("coleta_status", { status: "error", message: errorMessage });
        });

        // Quando o processo termina
        processo.on("close", (code) => {
            console.log(`Processo finalizado com código ${code}`);
            if (code === 0) {
                io.emit("coleta_status", { status: "success", message: "✅ Enriquecimento concluído com sucesso!" });
                res.status(200).json({ message: "Enriquecimento concluído com sucesso!", logs });
            } else {
                io.emit("coleta_status", { status: "error", message: "❌ Erro no enriquecimento." });
                res.status(500).json({ error: "Erro no enriquecimento", logs });
            }
        });

        // Captura erro caso o processo falhe ao iniciar
        processo.on("error", (error) => {
            console.error("Erro ao iniciar enriquecimentos_ordens.py", error);
            io.emit("coleta_status", { status: "error", message: "❌ Erro ao iniciar enriquecimento." });
            res.status(500).json({ error: "Erro ao executar o processo", details: error.message });
        });
    } catch (error) {
        console.error("Erro ao iniciar enriquecimentos_ordens.py", error);
        io.emit("coleta_status", { status: "error", message: "❌ Erro crítico ao iniciar enriquecimento." });
        res.status(500).json({ error: "Erro ao executar o processo", details: error.message });
    }
};

const executarAutomacao = (scriptName, res) => {
    const scriptPath = path.join(__dirname, "../microservices", `${scriptName}.py`);

    console.log(`🔹 Executando automação: ${scriptPath}`);

    execFile("python", [scriptPath], (error, stdout, stderr) => {
        if (error) {
            console.error(`❌ Erro ao executar ${scriptName}:`, error.message);
            registrarLog(`Erro ao executar ${scriptName}: ${stderr}`);
            io.emit('coleta_status', { status: 'error', message: `Erro ao executar ${scriptName}: ${stderr}` });

            let statusCode = 500;
            let errorMessage = `Erro ao executar ${scriptName}`;

            if (error.code === "ENOENT") {
                statusCode = 404;
                errorMessage = `Arquivo ${scriptName}.py não encontrado.`;
            }

            return res.status(statusCode).json({ error: errorMessage, details: stderr });
        }

        const output = stdout.trim() || "Sem saída";
        registrarLog(`✅ Automação ${scriptName} executada com sucesso.`);
        io.emit('coleta_status', { status: 'success', message: `Automação ${scriptName} executada com sucesso!` });
        res.json({ message: `Automação ${scriptName} executada com sucesso!`, output: output });
    });
};

module.exports = { iniciarColetaOrdens, pararColetaOrdens, enriquecerOrdens, executarAutomacao };

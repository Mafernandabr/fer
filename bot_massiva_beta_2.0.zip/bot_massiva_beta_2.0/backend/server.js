// backend/server.js
// Carregar variáveis de ambiente
require("dotenv").config();

const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const mysql = require("mysql2");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

// Importação dinâmica do módulo 'open'
let open;
import("open").then((module) => {
    open = module.default;
}).catch((err) => {
    console.error("❌ Erro ao carregar o módulo 'open':", err);
});

// Configuração do pool de conexões
const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT,
    waitForConnections: true,
    connectionLimit: 20,
    queueLimit: 0
});

// Criar servidor HTTP e WebSocket
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*", // Permitir conexões de qualquer origem
        methods: ["GET", "POST"]
    }
});

// Função para registrar logs no banco de dados
const registrarLog = async (descricao) => {
    try {
        await pool.promise().query("INSERT INTO tb_logs (descricao) VALUES (?)", [descricao]);
    } catch (error) {
        console.error("❌ Erro ao registrar log:", error);
    }
};

// Função para obter o WebSocket
const getIo = () => io;

// Exportação dos módulos após a definição das funções
module.exports = { pool: pool.promise(), registrarLog, getIo };

// Teste de conexão com o banco ao iniciar
(async () => {
    try {
        const connection = await pool.promise().getConnection();
        console.log("✅ Conexão ao banco bem-sucedida!");
        connection.release();
    } catch (error) {
        console.error("❌ Erro ao conectar ao banco de dados:", error);
    }
})();

// Configuração do servidor Express
app.use(express.json());
app.use(express.static(path.join(__dirname, "../frontend"))); // Serve os arquivos estáticos do frontend

// Rota para servir o arquivo index.html
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

// Importação das rotas de automações
const automacoesRoutes = require("./routes/automacoesRoutes");
app.use("/automacoes", automacoesRoutes);

// Configuração do WebSocket
io.on("connection", (socket) => {
    console.log("Novo cliente conectado");
    socket.emit("message", "Conexão WebSocket estabelecida!");
    socket.on("disconnect", () => {
        console.log("Cliente desconectado");
    });
});

// Inicia o servidor
server.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
    import("open").then((module) => {
        module.default(`http://localhost:${PORT}`)
            .then(() => console.log("Navegador aberto automaticamente."))
            .catch(err => console.error("❌ Erro ao abrir o navegador:", err));
    }).catch((err) => {
        console.error("❌ Erro ao carregar o módulo 'open':", err);
    });
});

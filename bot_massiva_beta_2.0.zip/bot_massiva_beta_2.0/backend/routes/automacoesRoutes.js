// backend/routes/automacoesRoutes.js
const express = require("express");
const router = express.Router();
const automacoesController = require("../controllers/automacoesController");

router.get("/coletar-ordens", (req, res) => automacoesController.iniciarColetaOrdens(res));
router.get("/parar-coleta", (req, res) => automacoesController.pararColetaOrdens(res));
router.get("/enriquecer-ordens", (req, res) => automacoesController.executarAutomacao("enriquecimentos_ordens", res));
router.get("/limpar-dados", (req, res) => automacoesController.executarAutomacao("limpeza_dados", res));

module.exports = router;
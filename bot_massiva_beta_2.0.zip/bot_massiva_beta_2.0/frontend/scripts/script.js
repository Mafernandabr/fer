// frontend/scripts/script.js
const socket = io();

async function executarAutomacao(acao) {
    const tabela = document.getElementById("tabela-resultados").getElementsByTagName('tbody')[0];
    let linha = tabela.insertRow();
    
    linha.insertCell(0).innerText = acao;
    let statusCell = linha.insertCell(1);
    let outputCell = linha.insertCell(2);

    // Mostra o indicador de carregamento
    document.getElementById("loading").classList.remove("hidden");

    statusCell.innerText = "⏳ Processando...";

    try {
        const response = await fetch(`http://localhost:3000/automacoes/${acao}`);
        const data = await response.json();
        
        document.getElementById("loading").classList.add("hidden"); // Esconde o indicador

        if (data.error) {
            statusCell.innerText = "❌ Erro";
            outputCell.innerHTML = `<pre style="color: red;">${data.details || "Erro ao executar"}</pre>`;
            console.error(`Erro ao executar ${acao}: ${data.details}`);
        } else {
            statusCell.innerText = "✅ Concluído";
            outputCell.innerHTML = `<pre>${data.output || "Sem retorno"}</pre>`;
            console.log(`Sucesso ao executar ${acao}:`, data.output);
        }

        // Criar botão para baixar logs se houver erro
        if (data.error) {
            let logButton = document.createElement("button");
            logButton.innerText = "Baixar Log";
            logButton.onclick = () => baixarLog(data.details);
            outputCell.appendChild(document.createElement("br"));
            outputCell.appendChild(logButton);
        }

    } catch (error) {
        document.getElementById("loading").classList.add("hidden");
        statusCell.innerText = "❌ Erro";
        outputCell.innerHTML = `<pre style="color: red;">Erro ao executar requisição</pre>`;
        console.error(`Erro ao conectar ao servidor: ${error}`);
    }
}

// Função para baixar logs em um arquivo .txt
function baixarLog(log) {
    const blob = new Blob([log], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "log_automacao.txt";
    a.click();
}

// Adicionando eventos nos botões
document.getElementById("coletar").addEventListener("click", () => executarAutomacao("coletar-ordens"));
document.getElementById("parar").addEventListener("click", () => executarAutomacao("parar-coleta"));
document.getElementById("enriquecer").addEventListener("click", () => executarAutomacao("enriquecer-ordens"));
document.getElementById("limpar").addEventListener("click", () => executarAutomacao("limpar-dados"));

// Receber atualizações do WebSocket
socket.on('coleta_status', (data) => {
    const tabela = document.getElementById("tabela-resultados").getElementsByTagName('tbody')[0];
    let linha = tabela.insertRow();
    
    linha.insertCell(0).innerText = 'Coletar Ordens';
    let statusCell = linha.insertCell(1);
    let outputCell = linha.insertCell(2);
    
    if (data.status === 'error') {
        statusCell.innerText = "❌ Erro";
        outputCell.innerHTML = `<pre style="color: red;">${data.message}</pre>`;
    } else if (data.status === 'success') {
        statusCell.innerText = "✅ Concluído";
        outputCell.innerHTML = `<pre>${data.message}</pre>`;
    } else {
        statusCell.innerText = "⏳ Processando...";
        outputCell.innerHTML = `<pre>${data.message}</pre>`;
    }
});
